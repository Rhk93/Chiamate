// Chiamate - Copyright © Ignazio Paolicelli
package com.ignazio.chiamate;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.VideoProfile;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Schermata di chiamata (in arrivo / in corso) in stile iPhone. */
public class InCallActivity extends Activity implements GestoreChiamate.Ascoltatore {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView nomeView, statoView;
    private LinearLayout griglia, tastierinoDtmf, rigaArrivo, rigaFine;
    private TextView nascondi;
    private FrameLayout btnMuto, btnAltoparlante, btnAttesa;
    private ImageView icoMuto, icoAltoparlante, icoAttesa;
    private final StringBuilder cifreDtmf = new StringBuilder();
    private long inizioLocale = 0;
    private boolean chiusuraProgrammata = false;
    private PowerManager.WakeLock prossimita;

    private final Runnable cronometro = new Runnable() {
        @Override
        public void run() {
            aggiornaStato();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Stile.carica(this);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        w.setStatusBarColor(0xFF2C2C2E);
        w.setNavigationBarColor(0xFF1C1C1E);
        setShowWhenLocked(true);
        setTurnScreenOn(true);

        PowerManager pm = getSystemService(PowerManager.class);
        if (pm != null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            prossimita = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "chiamate:prossimita");
        }

        setContentView(costruisci());
        GestoreChiamate.aggiungiAscoltatore(this);
        gestisciAzione(getIntent());
        aggiorna();
        handler.post(cronometro);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        gestisciAzione(intent);
        aggiorna();
    }

    @Override
    protected void onDestroy() {
        GestoreChiamate.rimuoviAscoltatore(this);
        handler.removeCallbacksAndMessages(null);
        if (prossimita != null && prossimita.isHeld()) prossimita.release();
        super.onDestroy();
    }

    private void gestisciAzione(Intent i) {
        if (i == null) return;
        String azione = i.getStringExtra("azione");
        i.removeExtra("azione");
        if (azione == null) return;
        Call c = GestoreChiamate.attuale();
        if (c == null) return;
        if (azione.equals("rispondi")) rispondi();
        else if (azione.equals("rifiuta")) c.reject(false, null);
        else if (azione.equals("termina")) c.disconnect();
    }

    // ------------------------------------------------------------ interfaccia

    private int dp(float v) {
        return Stile.dp(this, v);
    }

    private View costruisci() {
        FrameLayout radice = new FrameLayout(this);
        GradientDrawable sfondo = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF2C2C2E, 0xFF3A3A3C, 0xFF1C1C1E});
        radice.setBackground(sfondo);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        radice.addView(col, new FrameLayout.LayoutParams(-1, -1));

        nomeView = Stile.testo(this, "", 34, 0xFFFFFFFF, false);
        nomeView.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        nomeView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lpN = new LinearLayout.LayoutParams(-1, -2);
        lpN.topMargin = dp(70);
        lpN.leftMargin = dp(24);
        lpN.rightMargin = dp(24);
        col.addView(nomeView, lpN);

        statoView = Stile.testo(this, "", 17, 0xFFD1D1D6, false);
        statoView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lpS = new LinearLayout.LayoutParams(-1, -2);
        lpS.topMargin = dp(8);
        col.addView(statoView, lpS);

        View spazio = new View(this);
        col.addView(spazio, new LinearLayout.LayoutParams(1, 0, 1f));

        FrameLayout pannello = new FrameLayout(this);
        col.addView(pannello, new LinearLayout.LayoutParams(-2, -2));

        // --- griglia di 6 pulsanti
        griglia = new LinearLayout(this);
        griglia.setOrientation(LinearLayout.VERTICAL);
        LinearLayout r1 = riga();
        LinearLayout r2 = riga();
        btnMuto = pulsanteCerchio(r1, R.drawable.ic_microfono, "silenzioso");
        icoMuto = (ImageView) btnMuto.getChildAt(0);
        FrameLayout btnTast = pulsanteCerchio(r1, R.drawable.ic_tastierino, "tastierino");
        btnAltoparlante = pulsanteCerchio(r1, R.drawable.ic_altoparlante, "altoparlante");
        icoAltoparlante = (ImageView) btnAltoparlante.getChildAt(0);
        FrameLayout btnAgg = pulsanteCerchio(r2, R.drawable.ic_aggiungi, "aggiungi");
        btnAttesa = pulsanteCerchio(r2, R.drawable.ic_pausa, "attesa");
        icoAttesa = (ImageView) btnAttesa.getChildAt(0);
        FrameLayout btnCont = pulsanteCerchio(r2, R.drawable.ic_persona, "contatti");
        griglia.addView(r1);
        LinearLayout.LayoutParams lpR2 = new LinearLayout.LayoutParams(-2, -2);
        lpR2.topMargin = dp(22);
        griglia.addView(r2, lpR2);
        pannello.addView(griglia, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        btnMuto.setOnClickListener(v -> {
            if (GestoreChiamate.servizio == null) return;
            CallAudioState s = GestoreChiamate.servizio.getCallAudioState();
            GestoreChiamate.servizio.setMuted(s == null || !s.isMuted());
        });
        btnAltoparlante.setOnClickListener(v -> {
            if (GestoreChiamate.servizio == null) return;
            CallAudioState s = GestoreChiamate.servizio.getCallAudioState();
            boolean attivo = s != null && s.getRoute() == CallAudioState.ROUTE_SPEAKER;
            GestoreChiamate.servizio.setAudioRoute(attivo
                    ? CallAudioState.ROUTE_WIRED_OR_EARPIECE : CallAudioState.ROUTE_SPEAKER);
        });
        btnAttesa.setOnClickListener(v -> {
            Call c = GestoreChiamate.attuale();
            if (c == null) return;
            if (statoDi(c) == Call.STATE_HOLDING) c.unhold();
            else c.hold();
        });
        btnTast.setOnClickListener(v -> mostraTastierino(true));
        btnAgg.setOnClickListener(v -> apriApp(3));
        btnCont.setOnClickListener(v -> apriApp(2));

        // --- tastierino DTMF
        tastierinoDtmf = new LinearLayout(this);
        tastierinoDtmf.setOrientation(LinearLayout.VERTICAL);
        tastierinoDtmf.setVisibility(View.GONE);
        String[] tasti = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"};
        String[] lettere = {"", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ", "", "+", ""};
        for (int r = 0; r < 4; r++) {
            LinearLayout rr = riga();
            for (int k = 0; k < 3; k++) {
                int idx = r * 3 + k;
                rr.addView(tastoDtmf(tasti[idx], lettere[idx], k > 0));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            if (r > 0) lp.topMargin = dp(14);
            tastierinoDtmf.addView(rr, lp);
        }
        pannello.addView(tastierinoDtmf, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        // --- riga in basso: chiamata in corso
        rigaFine = new LinearLayout(this);
        rigaFine.setOrientation(LinearLayout.HORIZONTAL);
        rigaFine.setGravity(Gravity.CENTER_VERTICAL);
        View sx = new View(this);
        rigaFine.addView(sx, new LinearLayout.LayoutParams(dp(98), 1));
        FrameLayout fine = cerchioColorato(R.drawable.ic_riaggancia, Stile.ROSSO);
        fine.setOnClickListener(v -> {
            Call c = GestoreChiamate.attuale();
            if (c != null) c.disconnect();
            else finish();
        });
        rigaFine.addView(fine);
        nascondi = Stile.testo(this, "Nascondi", 17, 0xFFFFFFFF, false);
        nascondi.setGravity(Gravity.CENTER);
        nascondi.setVisibility(View.INVISIBLE);
        nascondi.setOnClickListener(v -> mostraTastierino(false));
        rigaFine.addView(nascondi, new LinearLayout.LayoutParams(dp(98), dp(76)));
        LinearLayout.LayoutParams lpF = new LinearLayout.LayoutParams(-2, -2);
        lpF.topMargin = dp(36);
        lpF.bottomMargin = dp(56);
        col.addView(rigaFine, lpF);

        // --- riga in basso: chiamata in arrivo
        rigaArrivo = new LinearLayout(this);
        rigaArrivo.setOrientation(LinearLayout.HORIZONTAL);
        rigaArrivo.setVisibility(View.GONE);
        LinearLayout rif = conEtichetta(cerchioColorato(R.drawable.ic_riaggancia, Stile.ROSSO), "Rifiuta");
        rif.getChildAt(0).setOnClickListener(v -> {
            Call c = GestoreChiamate.attuale();
            if (c != null) c.reject(false, null);
        });
        LinearLayout acc = conEtichetta(cerchioColorato(R.drawable.ic_chiama, Stile.VERDE), "Accetta");
        acc.getChildAt(0).setOnClickListener(v -> rispondi());
        rigaArrivo.addView(rif);
        View mezzo = new View(this);
        rigaArrivo.addView(mezzo, new LinearLayout.LayoutParams(dp(110), 1));
        rigaArrivo.addView(acc);
        LinearLayout.LayoutParams lpA = new LinearLayout.LayoutParams(-2, -2);
        lpA.bottomMargin = dp(70);
        col.addView(rigaArrivo, lpA);

        return radice;
    }

    private LinearLayout riga() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    /** Pulsante tondo traslucido con etichetta sotto (silenzioso, tastierino, ...). */
    private FrameLayout pulsanteCerchio(LinearLayout riga, int icona, String etichetta) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout cerchio = new FrameLayout(this);
        cerchio.setBackground(Stile.premibile(Stile.tondo(0x33FFFFFF), Stile.tondo(0x66FFFFFF)));
        ImageView iv = new ImageView(this);
        iv.setImageResource(icona);
        iv.setImageTintList(ColorStateList.valueOf(0xFFFFFFFF));
        cerchio.addView(iv, new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
        box.addView(cerchio, new LinearLayout.LayoutParams(dp(76), dp(76)));
        TextView t = Stile.testo(this, etichetta, 13, 0xFFFFFFFF, false);
        LinearLayout.LayoutParams lpT = new LinearLayout.LayoutParams(-2, -2);
        lpT.topMargin = dp(8);
        box.addView(t, lpT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(98), -2);
        lp.leftMargin = riga.getChildCount() > 0 ? dp(4) : 0;
        riga.addView(box, lp);
        return cerchio;
    }

    private void evidenzia(FrameLayout cerchio, ImageView iv, boolean attivo) {
        if (attivo) {
            cerchio.setBackground(Stile.premibile(Stile.tondo(0xFFFFFFFF), Stile.tondo(0xFFD1D1D6)));
            iv.setImageTintList(ColorStateList.valueOf(0xFF1C1C1E));
        } else {
            cerchio.setBackground(Stile.premibile(Stile.tondo(0x33FFFFFF), Stile.tondo(0x66FFFFFF)));
            iv.setImageTintList(ColorStateList.valueOf(0xFFFFFFFF));
        }
    }

    private FrameLayout cerchioColorato(int icona, int colore) {
        FrameLayout f = new FrameLayout(this);
        int scuro = (colore & 0x00FFFFFF) | 0xB0000000;
        f.setBackground(Stile.premibile(Stile.tondo(colore), Stile.tondo(scuro)));
        ImageView iv = new ImageView(this);
        iv.setImageResource(icona);
        iv.setImageTintList(ColorStateList.valueOf(0xFFFFFFFF));
        f.addView(iv, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(76), dp(76)));
        return f;
    }

    private LinearLayout conEtichetta(View cerchio, String testo) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.addView(cerchio);
        TextView t = Stile.testo(this, testo, 15, 0xFFFFFFFF, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(10);
        box.addView(t, lp);
        return box;
    }

    private View tastoDtmf(String cifra, String lettere, boolean margine) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Stile.premibile(Stile.tondo(0x33FFFFFF), Stile.tondo(0x80FFFFFF)));
        TextView c = Stile.testo(this, cifra, cifra.equals("*") ? 38 : 34, 0xFFFFFFFF, false);
        c.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        t.addView(c);
        if (!lettere.isEmpty()) {
            TextView l = Stile.testo(this, lettere, 10, 0xFFFFFFFF, true);
            l.setLetterSpacing(0.18f);
            t.addView(l);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(76), dp(76));
        if (margine) lp.leftMargin = dp(24);
        t.setLayoutParams(lp);
        final char ch = cifra.charAt(0);
        t.setOnTouchListener((v, e) -> {
            Call call = GestoreChiamate.attuale();
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                if (call != null) call.playDtmfTone(ch);
                cifreDtmf.append(ch);
                nomeView.setText(cifreDtmf.toString());
            } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                if (call != null) call.stopDtmfTone();
            }
            return false;
        });
        t.setOnClickListener(v -> { });
        return t;
    }

    private void mostraTastierino(boolean si) {
        griglia.setVisibility(si ? View.GONE : View.VISIBLE);
        tastierinoDtmf.setVisibility(si ? View.VISIBLE : View.GONE);
        nascondi.setVisibility(si ? View.VISIBLE : View.INVISIBLE);
        statoView.setVisibility(si ? View.GONE : View.VISIBLE);
        if (si && cifreDtmf.length() > 0) nomeView.setText(cifreDtmf.toString());
        if (!si) aggiorna();
    }

    private void apriApp(int scheda) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("scheda", scheda);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    // ------------------------------------------------------------ logica

    @SuppressWarnings("deprecation")
    private static int statoDi(Call c) {
        return c.getState();
    }

    private void rispondi() {
        Call c = GestoreChiamate.attuale();
        if (c == null) return;
        c.answer(VideoProfile.STATE_AUDIO_ONLY);
    }

    @Override
    public void aggiorna() {
        runOnUiThread(this::aggiornaSuUi);
    }

    private void aggiornaSuUi() {
        Call c = GestoreChiamate.attuale();
        if (c == null || statoDi(c) == Call.STATE_DISCONNECTED) {
            statoView.setText("Chiamata terminata");
            statoView.setVisibility(View.VISIBLE);
            rigaArrivo.setVisibility(View.GONE);
            if (prossimita != null && prossimita.isHeld()) prossimita.release();
            if (!chiusuraProgrammata) {
                chiusuraProgrammata = true;
                handler.postDelayed(() -> {
                    if (GestoreChiamate.attuale() == null) finish();
                    else chiusuraProgrammata = false;
                }, 1200);
            }
            return;
        }
        chiusuraProgrammata = false;
        String numero = GestoreChiamate.numero(c);
        String nome = Rubrica.nomeDaNumero(this, numero);
        if (tastierinoDtmf.getVisibility() != View.VISIBLE || cifreDtmf.length() == 0) {
            nomeView.setText(nome != null ? nome : (numero.isEmpty() ? "Sconosciuto" : numero));
        }

        int s = statoDi(c);
        boolean squilla = s == Call.STATE_RINGING;
        rigaArrivo.setVisibility(squilla ? View.VISIBLE : View.GONE);
        rigaFine.setVisibility(squilla ? View.GONE : View.VISIBLE);
        if (squilla) {
            griglia.setVisibility(View.INVISIBLE);
            tastierinoDtmf.setVisibility(View.GONE);
        } else if (tastierinoDtmf.getVisibility() != View.VISIBLE) {
            griglia.setVisibility(View.VISIBLE);
        }

        if (s == Call.STATE_ACTIVE && inizioLocale == 0) inizioLocale = System.currentTimeMillis();

        CallAudioState audio = GestoreChiamate.servizio != null ? GestoreChiamate.servizio.getCallAudioState() : null;
        boolean muto = audio != null && audio.isMuted();
        boolean altoparlante = audio != null && audio.getRoute() == CallAudioState.ROUTE_SPEAKER;
        evidenzia(btnMuto, icoMuto, muto);
        evidenzia(btnAltoparlante, icoAltoparlante, altoparlante);
        evidenzia(btnAttesa, icoAttesa, s == Call.STATE_HOLDING);

        // sensore di prossimità: spegne lo schermo vicino all'orecchio
        if (prossimita != null) {
            boolean serve = !squilla && !altoparlante && (s == Call.STATE_ACTIVE || s == Call.STATE_DIALING
                    || s == Call.STATE_CONNECTING);
            if (serve && !prossimita.isHeld()) prossimita.acquire(3 * 60 * 60 * 1000L);
            else if (!serve && prossimita.isHeld()) prossimita.release();
        }
        aggiornaStato();
    }

    private void aggiornaStato() {
        Call c = GestoreChiamate.attuale();
        if (c == null || statoView == null) return;
        int s = statoDi(c);
        String testo;
        switch (s) {
            case Call.STATE_RINGING:
                testo = "cellulare";
                break;
            case Call.STATE_DIALING:
            case Call.STATE_CONNECTING:
            case Call.STATE_NEW:
            case Call.STATE_SELECT_PHONE_ACCOUNT:
                testo = "chiamata in corso…";
                break;
            case Call.STATE_HOLDING:
                testo = "in attesa";
                break;
            case Call.STATE_ACTIVE: {
                long inizio = c.getDetails().getConnectTimeMillis();
                if (inizio <= 0) inizio = inizioLocale;
                long sec = Math.max(0, (System.currentTimeMillis() - inizio) / 1000);
                testo = sec >= 3600
                        ? String.format(java.util.Locale.ITALIAN, "%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)
                        : String.format(java.util.Locale.ITALIAN, "%02d:%02d", sec / 60, sec % 60);
                break;
            }
            case Call.STATE_DISCONNECTING:
            case Call.STATE_DISCONNECTED:
                testo = "Chiamata terminata";
                break;
            default:
                testo = "";
        }
        statoView.setText(testo);
    }

    @Override
    public void onBackPressed() {
        Call c = GestoreChiamate.attuale();
        if (c != null && statoDi(c) == Call.STATE_RINGING) return; // come su iPhone: si risponde o si rifiuta
        if (tastierinoDtmf.getVisibility() == View.VISIBLE) {
            mostraTastierino(false);
            return;
        }
        super.onBackPressed();
    }
}

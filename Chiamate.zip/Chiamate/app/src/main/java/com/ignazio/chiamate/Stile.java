package com.ignazio.chiamate;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Colori, misure e piccoli "mattoncini" grafici in stile iPhone. */
final class Stile {

    static final int BLU = 0xFF007AFF;
    static final int VERDE = 0xFF34C759;
    static final int ROSSO = 0xFFFF3B30;
    static final int GRIGIO_SCHEDA = 0xFF999999;

    static boolean scuro;
    static int SFONDO, TESTO, SECONDARIO, TASTO, TASTO_PREMUTO, SEPARATORE, BARRA, CAMPO, SCHEDA, SFONDO_GRUPPO;

    private Stile() { }

    static void carica(Context c) {
        int modo = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        int tema = c.getSharedPreferences("chiamate", Context.MODE_PRIVATE).getInt("tema", 0);
        if (tema == 1) scuro = false;
        else if (tema == 2) scuro = true;
        else scuro = modo == Configuration.UI_MODE_NIGHT_YES;
        if (scuro) {
            SFONDO = 0xFF000000;
            TESTO = 0xFFFFFFFF;
            SECONDARIO = 0xFF8E8E93;
            TASTO = 0xFF333333;
            TASTO_PREMUTO = 0xFF737373;
            SEPARATORE = 0xFF38383A;
            BARRA = 0xFF161616;
            CAMPO = 0xFF1C1C1E;
            SCHEDA = 0xFF1C1C1E;
            SFONDO_GRUPPO = 0xFF000000;
        } else {
            SFONDO = 0xFFFFFFFF;
            TESTO = 0xFF000000;
            SECONDARIO = 0xFF8E8E93;
            TASTO = 0xFFE5E5EA;
            TASTO_PREMUTO = 0xFFBCBCC0;
            SEPARATORE = 0xFFC6C6C8;
            BARRA = 0xFFF7F7F7;
            CAMPO = 0xFFEEEEF0;
            SCHEDA = 0xFFFFFFFF;
            SFONDO_GRUPPO = 0xFFF2F2F7;
        }
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable tondo(int colore) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(colore);
        return g;
    }

    static GradientDrawable rettangolo(int colore, float raggioPx) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(raggioPx);
        g.setColor(colore);
        return g;
    }

    static StateListDrawable premibile(Drawable normale, Drawable premuto) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, premuto);
        s.addState(new int[]{}, normale);
        s.setEnterFadeDuration(0);
        s.setExitFadeDuration(320); // come su iPhone: si illumina subito e si spegne piano
        return s;
    }

    /** Sfondo trasparente che diventa grigio chiaro quando la riga viene toccata. */
    static StateListDrawable rigaPremibile(int sfondo) {
        int premuto = scuro ? 0xFF2C2C2E : 0xFFD1D1D6;
        return premibile(rettangolo(sfondo, 0), rettangolo(premuto, 0));
    }

    static ImageView icona(Context c, int res, int colore, int dimDp) {
        ImageView iv = new ImageView(c);
        iv.setImageResource(res);
        iv.setImageTintList(ColorStateList.valueOf(colore));
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(c, dimDp), dp(c, dimDp)));
        return iv;
    }

    static TextView testo(Context c, String s, float sp, int colore, boolean grassetto) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(colore);
        t.setTypeface(Typeface.create("sans-serif", grassetto ? Typeface.BOLD : Typeface.NORMAL));
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setIncludeFontPadding(false);
        return t;
    }

    static TextView titoloGrande(Context c, String s) {
        TextView t = testo(c, s, 34, TESTO, true);
        t.setPadding(dp(c, 16), dp(c, 2), dp(c, 16), dp(c, 8));
        return t;
    }

    static TextView pulsanteTesto(Context c, String s) {
        TextView t = testo(c, s, 17, BLU, false);
        t.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    static View separatore(Context c, int rientroDp) {
        View v = new View(c);
        v.setBackgroundColor(SEPARATORE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.5f)));
        lp.leftMargin = dp(c, rientroDp);
        v.setLayoutParams(lp);
        return v;
    }

    static String iniziali(String nome) {
        if (nome == null) return "";
        String n = nome.trim();
        if (n.isEmpty()) return "";
        if (!Character.isLetter(n.charAt(0))) return "";
        String[] parti = n.split("\\s+");
        StringBuilder sb = new StringBuilder();
        sb.append(Character.toUpperCase(parti[0].charAt(0)));
        if (parti.length > 1 && !parti[parti.length - 1].isEmpty()
                && Character.isLetter(parti[parti.length - 1].charAt(0))) {
            sb.append(Character.toUpperCase(parti[parti.length - 1].charAt(0)));
        }
        return sb.toString();
    }

    /** Avatar tondo grigio con le iniziali (o la sagoma se il nome non ha lettere). */
    static View avatar(Context c, String nome, int dimDp) {
        android.widget.FrameLayout f = new android.widget.FrameLayout(c);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFA5ABB8, 0xFF858994});
        g.setShape(GradientDrawable.OVAL);
        f.setBackground(g);
        String ini = iniziali(nome);
        if (ini.isEmpty()) {
            ImageView iv = new ImageView(c);
            iv.setImageResource(R.drawable.ic_persona);
            iv.setImageTintList(ColorStateList.valueOf(0xFFFFFFFF));
            android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                    dp(c, dimDp * 0.62f), dp(c, dimDp * 0.62f), Gravity.CENTER);
            f.addView(iv, lp);
        } else {
            TextView t = testo(c, ini, dimDp * 0.4f, 0xFFFFFFFF, false);
            t.setGravity(Gravity.CENTER);
            f.addView(t, new android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
        }
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(c, dimDp), dp(c, dimDp)));
        return f;
    }
}

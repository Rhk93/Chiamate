package com.ignazio.chiamate;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;

/**
 * Servizio usato da Android quando "Chiamate" è l'app Telefono predefinita:
 * mostra la schermata di chiamata in stile iPhone.
 */
public class ChiamataService extends InCallService {

    private static final String CANALE_ARRIVO = "chiamate_arrivo";
    private static final String CANALE_CORSO = "chiamate_corso";
    private static final int ID_NOTIFICA = 7001;

    @Override
    public void onCreate() {
        super.onCreate();
        GestoreChiamate.servizio = this;
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel a = new NotificationChannel(CANALE_ARRIVO, "Chiamate in arrivo",
                NotificationManager.IMPORTANCE_HIGH);
        a.setSound(null, null);
        a.enableVibration(false);
        nm.createNotificationChannel(a);
        NotificationChannel b = new NotificationChannel(CANALE_CORSO, "Chiamata in corso",
                NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(b);
    }

    @Override
    public void onDestroy() {
        if (GestoreChiamate.servizio == this) GestoreChiamate.servizio = null;
        getSystemService(NotificationManager.class).cancel(ID_NOTIFICA);
        super.onDestroy();
    }

    @Override
    public void onCallAdded(Call call) {
        GestoreChiamate.servizio = this;
        GestoreChiamate.aggiunta(call);
        try {
            Intent i = new Intent(this, InCallActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i, android.app.ActivityOptions.makeCustomAnimation(this,
                    R.anim.chiamata_entra, R.anim.fermo).toBundle());
        } catch (Exception ignorata) {
            // la notifica a schermo intero farà il resto
        }
    }

    @Override
    public void onCallRemoved(Call call) {
        GestoreChiamate.rimossa(call);
    }

    @Override
    public void onCallAudioStateChanged(CallAudioState audioState) {
        GestoreChiamate.notifica();
    }

    private PendingIntent apri(String azione, int codice) {
        Intent i = new Intent(this, InCallActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (azione != null) i.putExtra("azione", azione);
        return PendingIntent.getActivity(this, codice, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @SuppressWarnings("deprecation")
    void aggiornaNotifica() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        Call c = GestoreChiamate.attuale();
        if (c == null || c.getState() == Call.STATE_DISCONNECTED) {
            nm.cancel(ID_NOTIFICA);
            return;
        }
        String numero = GestoreChiamate.numero(c);
        String nome = Rubrica.nomeDaNumero(this, numero);
        if (nome == null) nome = numero.isEmpty() ? "Sconosciuto" : numero;

        Notification.Builder b;
        if (c.getState() == Call.STATE_RINGING) {
            b = new Notification.Builder(this, CANALE_ARRIVO)
                    .setContentText("Chiamata in arrivo")
                    .setFullScreenIntent(apri(null, 1), true)
                    .addAction(new Notification.Action.Builder(
                            Icon.createWithResource(this, R.drawable.ic_riaggancia), "Rifiuta",
                            apri("rifiuta", 2)).build())
                    .addAction(new Notification.Action.Builder(
                            Icon.createWithResource(this, R.drawable.ic_chiama), "Rispondi",
                            apri("rispondi", 3)).build());
        } else {
            b = new Notification.Builder(this, CANALE_CORSO)
                    .setContentText("Chiamata in corso – tocca per tornare")
                    .setUsesChronometer(c.getState() == Call.STATE_ACTIVE)
                    .setWhen(c.getDetails().getConnectTimeMillis() > 0
                            ? c.getDetails().getConnectTimeMillis() : System.currentTimeMillis())
                    .addAction(new Notification.Action.Builder(
                            Icon.createWithResource(this, R.drawable.ic_riaggancia), "Termina",
                            apri("termina", 4)).build());
        }
        b.setSmallIcon(R.drawable.ic_chiama)
                .setContentTitle(nome)
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setColor(Stile.VERDE)
                .setContentIntent(apri(null, 5));
        try {
            nm.notify(ID_NOTIFICA, b.build());
        } catch (SecurityException ignorata) {
            // permesso notifiche negato
        }
    }
}

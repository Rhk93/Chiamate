package com.ignazio.chiamate;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;

/** Animazioni in stile iPhone. */
final class Anima {

    /** Curva "ease out" usata da iOS per gli spostamenti di schermata. */
    static final Interpolator IOS = new PathInterpolator(0.2f, 0.9f, 0.25f, 1f);
    static final int DURATA = 380;

    private Anima() { }

    /** Nuova schermata che entra da destra; quella sotto scivola un po' a sinistra e si scurisce. */
    static void entraDaDestra(View nuova, View sotto) {
        int w = Math.max(1, ((View) nuova.getParent()).getWidth());
        nuova.setTranslationX(w);
        nuova.animate().translationX(0).setDuration(DURATA).setInterpolator(IOS).start();
        if (sotto != null) {
            sotto.animate().translationX(-w * 0.3f).alpha(0.85f).setDuration(DURATA).setInterpolator(IOS).start();
        }
    }

    /** Schermata che esce verso destra (tasto indietro). */
    static void esceADestra(View pagina, View sotto, Runnable fine) {
        int w = Math.max(1, pagina.getWidth());
        pagina.animate().translationX(w).setDuration(320).setInterpolator(IOS)
                .withEndAction(fine).start();
        if (sotto != null) {
            sotto.animate().translationX(0).alpha(1f).setDuration(320).setInterpolator(IOS).start();
        }
    }

    /** Scorrimento dal bordo sinistro per tornare indietro, come su iPhone. */
    @SuppressLint("ClickableViewAccessibility")
    static void scorriIndietro(View bordo, View pagina, View sotto, Runnable chiudi) {
        final float[] inizio = {0};
        bordo.setOnTouchListener((v, e) -> {
            int w = Math.max(1, pagina.getWidth());
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    inizio[0] = e.getRawX();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = Math.max(0, e.getRawX() - inizio[0]);
                    pagina.setTranslationX(dx);
                    if (sotto != null) {
                        float f = dx / w;
                        sotto.setTranslationX(-w * 0.3f * (1 - f));
                        sotto.setAlpha(0.85f + 0.15f * f);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    float dx = e.getRawX() - inizio[0];
                    if (dx > w * 0.35f) {
                        esceADestra(pagina, sotto, chiudi);
                    } else {
                        pagina.animate().translationX(0).setDuration(250).setInterpolator(IOS).start();
                        if (sotto != null) {
                            sotto.animate().translationX(-w * 0.3f).alpha(0.85f).setDuration(250).start();
                        }
                    }
                    return true;
                }
                default:
                    return true;
            }
        });
    }

    /** Compare / scompare in dissolvenza. */
    static void dissolvi(View v, boolean visibile) {
        if (v == null) return;
        float a = visibile ? 1f : 0f;
        if (visibile && v.getVisibility() != View.VISIBLE) {
            v.setAlpha(0f);
            v.setVisibility(View.VISIBLE);
        }
        if (!visibile && v.getVisibility() != View.VISIBLE) return;
        v.animate().cancel();
        v.animate().alpha(a).setDuration(180).withEndAction(() -> {
            if (!visibile) v.setVisibility(View.INVISIBLE);
        }).start();
    }

    /** La riga si chiude in altezza e poi viene eliminata (come quando cancelli su iPhone). */
    static void chiudiRiga(View riga, Runnable fine) {
        final int h = riga.getHeight();
        ValueAnimator va = ValueAnimator.ofInt(h, 0);
        va.setDuration(280);
        va.setInterpolator(new DecelerateInterpolator());
        va.addUpdateListener(a -> {
            ViewGroup.LayoutParams lp = riga.getLayoutParams();
            lp.height = (int) a.getAnimatedValue();
            riga.setLayoutParams(lp);
            riga.setAlpha(lp.height / (float) Math.max(1, h));
        });
        va.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                if (fine != null) fine.run();
            }
        });
        va.start();
    }

    /**
     * Scorri la riga a sinistra per mostrare il pulsante rosso "Elimina" (dietro alla riga).
     * Il tocco normale continua a funzionare.
     */
    @SuppressLint("ClickableViewAccessibility")
    static void scorriPerEliminare(View riga, View elimina, int larghezzaPx) {
        final float[] st = {0, 0, 0};       // x iniziale, y iniziale, traslazione iniziale
        final boolean[] trascina = {false};
        final int soglia = ViewConfiguration.get(riga.getContext()).getScaledTouchSlop();
        riga.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    st[0] = e.getRawX();
                    st[1] = e.getRawY();
                    st[2] = v.getTranslationX();
                    trascina[0] = false;
                    return false;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - st[0];
                    float dy = e.getRawY() - st[1];
                    if (!trascina[0] && Math.abs(dx) > soglia && Math.abs(dx) > Math.abs(dy)) {
                        trascina[0] = true;
                        v.setPressed(false);
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    if (trascina[0]) {
                        float t = Math.min(0, st[2] + dx);
                        if (t < -larghezzaPx) t = -larghezzaPx + (t + larghezzaPx) * 0.3f; // resistenza
                        v.setTranslationX(t);
                        elimina.setAlpha(Math.min(1f, -t / larghezzaPx));
                        return true;
                    }
                    return false;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (trascina[0]) {
                        boolean apri = v.getTranslationX() < -larghezzaPx * 0.45f;
                        v.animate().translationX(apri ? -larghezzaPx : 0).setDuration(250).setInterpolator(IOS).start();
                        elimina.animate().alpha(apri ? 1f : 0f).setDuration(250).start();
                        trascina[0] = false;
                        return true;
                    }
                    if (v.getTranslationX() != 0 && e.getActionMasked() == MotionEvent.ACTION_UP) {
                        // tocco su una riga aperta: la richiude
                        v.animate().translationX(0).setDuration(250).setInterpolator(IOS).start();
                        elimina.animate().alpha(0f).setDuration(250).start();
                        v.setPressed(false);
                        return true;
                    }
                    return false;
                default:
                    return false;
            }
        });
    }
}

// Chiamate - Copyright © Ignazio Paolicelli
package com.ignazio.chiamate;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CallLog;
import android.provider.ContactsContract;

import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Lettura di contatti, chiamate recenti e gestione dei preferiti. */
final class Rubrica {

    private Rubrica() { }

    static final class Contatto {
        long id;
        String nome;
        final List<String[]> numeri = new ArrayList<>(); // {etichetta, numero}
    }

    static final class Recente {
        String nome;
        String numero;
        int tipo;
        long data;
        int conteggio = 1;
    }

    static boolean permesso(Context c, String p) {
        return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    // ---------------- Contatti ----------------

    static List<Contatto> contatti(Context c) {
        Map<Long, Contatto> mappa = new LinkedHashMap<>();
        if (!permesso(c, Manifest.permission.READ_CONTACTS)) return new ArrayList<>();
        String[] col = {
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE,
                ContactsContract.CommonDataKinds.Phone.LABEL
        };
        try (Cursor cur = c.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, col, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC")) {
            if (cur != null) {
                while (cur.moveToNext()) {
                    long id = cur.getLong(0);
                    String nome = cur.getString(1);
                    String numero = cur.getString(2);
                    if (numero == null) continue;
                    Contatto k = mappa.get(id);
                    if (k == null) {
                        k = new Contatto();
                        k.id = id;
                        k.nome = (nome == null || nome.trim().isEmpty()) ? numero : nome;
                        mappa.put(id, k);
                    }
                    String pulito = numero.replaceAll("[\\s\\-()]", "");
                    boolean doppio = false;
                    for (String[] n : k.numeri) {
                        if (n[1].replaceAll("[\\s\\-()]", "").equals(pulito)) { doppio = true; break; }
                    }
                    if (!doppio) k.numeri.add(new String[]{etichetta(cur.getInt(3), cur.getString(4)), numero});
                }
            }
        } catch (Exception ignorata) { }
        return new ArrayList<>(mappa.values());
    }

    static String etichetta(int tipo, String personalizzata) {
        switch (tipo) {
            case ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE: return "cellulare";
            case ContactsContract.CommonDataKinds.Phone.TYPE_HOME: return "casa";
            case ContactsContract.CommonDataKinds.Phone.TYPE_WORK: return "lavoro";
            case ContactsContract.CommonDataKinds.Phone.TYPE_MAIN: return "principale";
            case ContactsContract.CommonDataKinds.Phone.TYPE_FAX_WORK:
            case ContactsContract.CommonDataKinds.Phone.TYPE_FAX_HOME: return "fax";
            case ContactsContract.CommonDataKinds.Phone.TYPE_PAGER: return "cercapersone";
            case ContactsContract.CommonDataKinds.Phone.TYPE_CUSTOM:
                return personalizzata != null && !personalizzata.isEmpty() ? personalizzata : "altro";
            default: return "telefono";
        }
    }

    /** Lettera dell'indice (A-Z) oppure "#". */
    static String lettera(String nome) {
        if (nome == null || nome.isEmpty()) return "#";
        String s = Normalizer.normalize(nome.substring(0, 1), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toUpperCase(Locale.ITALIAN);
        char ch = s.isEmpty() ? '#' : s.charAt(0);
        return (ch >= 'A' && ch <= 'Z') ? String.valueOf(ch) : "#";
    }

    static String nomeDaNumero(Context c, String numero) {
        if (numero == null || numero.isEmpty()) return null;
        if (!permesso(c, Manifest.permission.READ_CONTACTS)) return null;
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(numero));
        try (Cursor cur = c.getContentResolver().query(uri,
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Exception ignorata) { }
        return null;
    }

    static long idDaNumero(Context c, String numero) {
        if (numero == null || numero.isEmpty()) return -1;
        if (!permesso(c, Manifest.permission.READ_CONTACTS)) return -1;
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(numero));
        try (Cursor cur = c.getContentResolver().query(uri,
                new String[]{ContactsContract.PhoneLookup._ID}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) return cur.getLong(0);
        } catch (Exception ignorata) { }
        return -1;
    }

    static Contatto contattoDaId(Context c, long id) {
        for (Contatto k : contatti(c)) if (k.id == id) return k;
        return null;
    }

    // ---------------- Recenti ----------------

    static List<Recente> recenti(Context c, boolean soloPerse) {
        List<Recente> lista = new ArrayList<>();
        if (!permesso(c, Manifest.permission.READ_CALL_LOG)) return lista;
        String[] col = {CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE};
        try (Cursor cur = c.getContentResolver().query(CallLog.Calls.CONTENT_URI, col, null, null,
                CallLog.Calls.DATE + " DESC")) {
            if (cur == null) return lista;
            int letti = 0;
            while (cur.moveToNext() && letti < 500) {
                letti++;
                Recente r = new Recente();
                r.numero = cur.getString(0) == null ? "" : cur.getString(0);
                r.nome = cur.getString(1);
                r.tipo = cur.getInt(2);
                r.data = cur.getLong(3);
                boolean persa = persa(r.tipo);
                if (soloPerse && !persa) continue;
                if (!lista.isEmpty()) {
                    Recente u = lista.get(lista.size() - 1);
                    if (u.numero.equals(r.numero) && persa(u.tipo) == persa && stessoGiorno(u.data, r.data)) {
                        u.conteggio++;
                        continue;
                    }
                }
                lista.add(r);
                if (lista.size() >= 200) break;
            }
        } catch (Exception ignorata) { }
        return lista;
    }

    static List<Recente> chiamateDi(Context c, String numero) {
        List<Recente> lista = new ArrayList<>();
        if (numero == null || !permesso(c, Manifest.permission.READ_CALL_LOG)) return lista;
        String[] col = {CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION};
        try (Cursor cur = c.getContentResolver().query(CallLog.Calls.CONTENT_URI, col,
                CallLog.Calls.NUMBER + "=?", new String[]{numero}, CallLog.Calls.DATE + " DESC")) {
            if (cur == null) return lista;
            while (cur.moveToNext() && lista.size() < 20) {
                Recente r = new Recente();
                r.numero = cur.getString(0);
                r.tipo = cur.getInt(1);
                r.data = cur.getLong(2);
                r.conteggio = cur.getInt(3); // qui: durata in secondi
                lista.add(r);
            }
        } catch (Exception ignorata) { }
        return lista;
    }

    static boolean persa(int tipo) {
        return tipo == CallLog.Calls.MISSED_TYPE || tipo == CallLog.Calls.REJECTED_TYPE;
    }

    static String descrizioneTipo(int tipo) {
        switch (tipo) {
            case CallLog.Calls.OUTGOING_TYPE: return "In uscita";
            case CallLog.Calls.INCOMING_TYPE: return "In arrivo";
            case CallLog.Calls.MISSED_TYPE: return "Persa";
            case CallLog.Calls.REJECTED_TYPE: return "Rifiutata";
            case CallLog.Calls.BLOCKED_TYPE: return "Bloccata";
            case CallLog.Calls.VOICEMAIL_TYPE: return "Segreteria";
            default: return "Chiamata";
        }
    }

    static boolean stessoGiorno(long a, long b) {
        Calendar x = Calendar.getInstance();
        x.setTimeInMillis(a);
        Calendar y = Calendar.getInstance();
        y.setTimeInMillis(b);
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR);
    }

    /** Come l'iPhone: ora se oggi, "Ieri", giorno della settimana, oppure data. */
    static String quando(long t) {
        long ora = System.currentTimeMillis();
        if (stessoGiorno(t, ora)) return new SimpleDateFormat("HH:mm", Locale.ITALIAN).format(new Date(t));
        if (stessoGiorno(t, ora - 86400000L)) return "Ieri";
        if (ora - t < 6L * 86400000L) {
            String g = new SimpleDateFormat("EEEE", Locale.ITALIAN).format(new Date(t));
            return g.substring(0, 1).toUpperCase(Locale.ITALIAN) + g.substring(1);
        }
        return new SimpleDateFormat("dd/MM/yy", Locale.ITALIAN).format(new Date(t));
    }

    static String dataCompleta(long t) {
        return new SimpleDateFormat("d MMMM yyyy, HH:mm", Locale.ITALIAN).format(new Date(t));
    }

    // ---------------- Preferiti ----------------

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("chiamate", Context.MODE_PRIVATE);
    }

    /** Ogni preferito: {nome, numero, etichetta}. */
    static List<String[]> preferiti(Context c) {
        List<String[]> lista = new ArrayList<>();
        String s = prefs(c).getString("preferiti", "");
        if (s.isEmpty()) return lista;
        for (String riga : s.split("\n")) {
            String[] p = riga.split("\t", -1);
            if (p.length >= 3) lista.add(new String[]{p[0], p[1], p[2]});
        }
        return lista;
    }

    private static void salvaPreferiti(Context c, List<String[]> lista) {
        StringBuilder sb = new StringBuilder();
        for (String[] p : lista) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(pulisci(p[0])).append('\t').append(pulisci(p[1])).append('\t').append(pulisci(p[2]));
        }
        prefs(c).edit().putString("preferiti", sb.toString()).apply();
    }

    private static String pulisci(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ');
    }

    static boolean preferito(Context c, String numero) {
        for (String[] p : preferiti(c)) if (p[1].equals(numero)) return true;
        return false;
    }

    static void aggiungiPreferito(Context c, String nome, String numero, String etichetta) {
        if (preferito(c, numero)) return;
        List<String[]> l = preferiti(c);
        l.add(new String[]{nome, numero, etichetta == null ? "cellulare" : etichetta});
        salvaPreferiti(c, l);
    }

    static void rimuoviPreferito(Context c, String numero) {
        List<String[]> l = preferiti(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i)[1].equals(numero)) l.remove(i);
        salvaPreferiti(c, l);
    }

    // ---------------- Varie ----------------

    static String ultimoNumero(Context c) {
        return prefs(c).getString("ultimo", "");
    }

    static void salvaUltimoNumero(Context c, String n) {
        prefs(c).edit().putString("ultimo", n).apply();
    }

    static int ultimaScheda(Context c) {
        return prefs(c).getInt("scheda", 3);
    }

    static void salvaScheda(Context c, int i) {
        prefs(c).edit().putInt("scheda", i).apply();
    }

    static boolean primoAvvio(Context c) {
        boolean p = prefs(c).getBoolean("primo", true);
        if (p) prefs(c).edit().putBoolean("primo", false).apply();
        return p;
    }
}

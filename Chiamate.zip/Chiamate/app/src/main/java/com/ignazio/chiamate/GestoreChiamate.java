// Chiamate - Copyright © Ignazio Paolicelli
package com.ignazio.chiamate;

import android.net.Uri;
import android.telecom.Call;

import java.util.ArrayList;
import java.util.List;

/** Tiene traccia delle chiamate in corso e avvisa le schermate quando cambiano. */
final class GestoreChiamate {

    interface Ascoltatore {
        void aggiorna();
    }

    static ChiamataService servizio;
    static final List<Call> chiamate = new ArrayList<>();
    private static final List<Ascoltatore> ascoltatori = new ArrayList<>();

    private GestoreChiamate() { }

    private static final Call.Callback richiamo = new Call.Callback() {
        @Override
        public void onStateChanged(Call call, int state) {
            notifica();
        }

        @Override
        public void onDetailsChanged(Call call, Call.Details details) {
            notifica();
        }
    };

    /** La chiamata "principale": quella che squilla, altrimenti l'ultima aggiunta. */
    @SuppressWarnings("deprecation")
    static Call attuale() {
        for (Call c : chiamate) if (c.getState() == Call.STATE_RINGING) return c;
        for (int i = chiamate.size() - 1; i >= 0; i--) {
            if (chiamate.get(i).getState() != Call.STATE_HOLDING) return chiamate.get(i);
        }
        return chiamate.isEmpty() ? null : chiamate.get(chiamate.size() - 1);
    }

    static void aggiunta(Call c) {
        if (!chiamate.contains(c)) chiamate.add(c);
        c.registerCallback(richiamo);
        notifica();
    }

    static void rimossa(Call c) {
        c.unregisterCallback(richiamo);
        chiamate.remove(c);
        notifica();
    }

    static void aggiungiAscoltatore(Ascoltatore a) {
        if (!ascoltatori.contains(a)) ascoltatori.add(a);
    }

    static void rimuoviAscoltatore(Ascoltatore a) {
        ascoltatori.remove(a);
    }

    static void notifica() {
        for (Ascoltatore a : new ArrayList<>(ascoltatori)) a.aggiorna();
        if (servizio != null) servizio.aggiornaNotifica();
    }

    static String numero(Call c) {
        if (c == null || c.getDetails() == null) return "";
        Uri h = c.getDetails().getHandle();
        return h == null ? "" : h.getSchemeSpecificPart();
    }
}

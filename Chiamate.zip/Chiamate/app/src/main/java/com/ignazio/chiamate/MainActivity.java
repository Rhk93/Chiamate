package com.ignazio.chiamate;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.BlockedNumberContract;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telecom.Call;
import android.telecom.TelecomManager;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** App "Chiamate": Preferiti, Recenti, Contatti, Tastierino e Segreteria in stile iPhone. */
public class MainActivity extends Activity implements GestoreChiamate.Ascoltatore {

    private static final int REQ_PERMESSI = 1;
    private static final int REQ_CHIAMA = 2;
    private static final int REQ_RUOLO = 3;

    private static final String[] NOMI_SCHEDE = {"Preferiti", "Recenti", "Contatti", "Tastierino", "Segreteria"};
    private static final int[] ICONE_SCHEDE = {R.drawable.ic_stella, R.drawable.ic_orologio,
            R.drawable.ic_persona, R.drawable.ic_tastierino, R.drawable.ic_segreteria};
    private static final String[] LETTERE = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
            "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "#"};

    private FrameLayout contenuto;
    private LinearLayout barra;
    private TextView banner;
    private int scheda;
    private View dettaglio;
    private boolean giaMostrato = false;

    private final StringBuilder digitato = new StringBuilder();
    private TextView display, sottoDisplay;
    private View cancella;
    private ToneGenerator toni;
    private Uri uriInAttesa;

    private boolean soloPerse = false;
    private boolean modificaPreferiti = false;
    private boolean sceltaPreferito = false;
    private static boolean riapriImpostazioni = false;

    // ============================================================ ciclo di vita

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Stile.carica(this);
        setTheme(Stile.scuro ? android.R.style.Theme_Material_NoActionBar
                : android.R.style.Theme_Material_Light_NoActionBar);
        super.onCreate(savedInstanceState);
        coloraFinestra();

        LinearLayout radice = new LinearLayout(this);
        radice.setOrientation(LinearLayout.VERTICAL);
        radice.setBackgroundColor(Stile.SFONDO);

        banner = Stile.testo(this, "Tocca per tornare alla chiamata", 14, 0xFFFFFFFF, true);
        banner.setGravity(Gravity.CENTER);
        banner.setBackgroundColor(Stile.VERDE);
        banner.setVisibility(View.GONE);
        banner.setOnClickListener(v -> startActivity(new Intent(this, InCallActivity.class)));
        radice.addView(banner, new LinearLayout.LayoutParams(-1, dp(30)));

        contenuto = new FrameLayout(this);
        radice.addView(contenuto, new LinearLayout.LayoutParams(-1, 0, 1f));
        radice.addView(Stile.separatore(this, 0));
        barra = creaBarra();
        radice.addView(barra, new LinearLayout.LayoutParams(-1, dp(56)));
        setContentView(radice);

        try {
            toni = new ToneGenerator(AudioManager.STREAM_DTMF, 70);
        } catch (RuntimeException e) {
            toni = null;
        }

        scheda = Rubrica.ultimaScheda(this);
        gestisciIntent(getIntent());
        mostraScheda(scheda);
        giaMostrato = true;
        if (riapriImpostazioni) {
            riapriImpostazioni = false;
            apriImpostazioni();
        }

        if (Rubrica.primoAvvio(this)) richiediRuolo();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        chiudiDettaglio();
        gestisciIntent(intent);
        mostraScheda(scheda);
    }

    @Override
    protected void onResume() {
        super.onResume();
        GestoreChiamate.aggiungiAscoltatore(this);
        aggiornaBanner();
        if (giaMostrato && dettaglio == null && scheda != 3 && scheda != 2) mostraScheda(scheda);
    }

    @Override
    protected void onPause() {
        GestoreChiamate.rimuoviAscoltatore(this);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (toni != null) toni.release();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (dettaglio != null) {
            chiudiDettaglio();
            return;
        }
        if (sceltaPreferito) {
            sceltaPreferito = false;
            mostraScheda(0);
            return;
        }
        super.onBackPressed();
    }

    private void gestisciIntent(Intent i) {
        if (i == null) return;
        int s = i.getIntExtra("scheda", -1);
        String azione = i.getAction();
        if (Intent.ACTION_DIAL.equals(azione) || Intent.ACTION_VIEW.equals(azione)) {
            Uri d = i.getData();
            digitato.setLength(0);
            if (d != null && "tel".equals(d.getScheme()) && d.getSchemeSpecificPart() != null) {
                digitato.append(d.getSchemeSpecificPart());
            }
            s = 3;
        }
        if (s >= 0 && s <= 4) scheda = s;
    }

    @SuppressWarnings("deprecation")
    private void coloraFinestra() {
        Window w = getWindow();
        w.setStatusBarColor(Stile.SFONDO);
        w.setNavigationBarColor(Stile.BARRA);
        int f = 0;
        if (!Stile.scuro) f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(f);
    }

    private int dp(float v) {
        return Stile.dp(this, v);
    }

    // ============================================================ chiamata in corso (banner verde)

    @Override
    public void aggiorna() {
        runOnUiThread(this::aggiornaBanner);
    }

    @SuppressWarnings("deprecation")
    private void aggiornaBanner() {
        Call c = GestoreChiamate.attuale();
        boolean vis = c != null && c.getState() != Call.STATE_DISCONNECTED;
        banner.setVisibility(vis ? View.VISIBLE : View.GONE);
    }

    // ============================================================ barra delle schede

    private LinearLayout creaBarra() {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setBackgroundColor(Stile.BARRA);
        for (int i = 0; i < NOMI_SCHEDE.length; i++) {
            final int idx = i;
            LinearLayout voce = new LinearLayout(this);
            voce.setOrientation(LinearLayout.VERTICAL);
            voce.setGravity(Gravity.CENTER);
            ImageView ic = Stile.icona(this, ICONE_SCHEDE[i], Stile.GRIGIO_SCHEDA, 26);
            voce.addView(ic);
            TextView t = Stile.testo(this, NOMI_SCHEDE[i], 10, Stile.GRIGIO_SCHEDA, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(3);
            voce.addView(t, lp);
            voce.setOnClickListener(v -> {
                chiudiDettaglio();
                if (idx != 2) sceltaPreferito = false;
                if (idx != 0) modificaPreferiti = false;
                mostraScheda(idx);
            });
            b.addView(voce, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        return b;
    }

    private void aggiornaBarra() {
        for (int i = 0; i < barra.getChildCount(); i++) {
            LinearLayout voce = (LinearLayout) barra.getChildAt(i);
            int col = i == scheda ? Stile.BLU : Stile.GRIGIO_SCHEDA;
            ((ImageView) voce.getChildAt(0)).setImageTintList(ColorStateList.valueOf(col));
            ((TextView) voce.getChildAt(1)).setTextColor(col);
        }
    }

    private void mostraScheda(int i) {
        scheda = i;
        Rubrica.salvaScheda(this, i);
        contenuto.removeAllViews();
        dettaglio = null;
        View v;
        switch (i) {
            case 0: v = creaPreferiti(); break;
            case 1: v = creaRecenti(); break;
            case 2: v = creaContatti(); break;
            case 4: v = creaSegreteria(); break;
            default: v = creaTastierino(); break;
        }
        contenuto.addView(v, new FrameLayout.LayoutParams(-1, -1));
        aggiornaBarra();
    }

    /** Barra in alto (sinistra / centro / destra) + titolo grande come su iPhone. */
    private LinearLayout intestazione(View sinistra, View centro, View destra, String titolo) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        FrameLayout su = new FrameLayout(this);
        if (sinistra != null) su.addView(sinistra, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));
        if (centro != null) su.addView(centro, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        if (destra != null) su.addView(destra, new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL));
        col.addView(su, new LinearLayout.LayoutParams(-1, dp(46)));
        if (titolo != null) col.addView(Stile.titoloGrande(this, titolo));
        return col;
    }

    private View vuoto(String titolo, String testo, String pulsante, View.OnClickListener azione) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(32), dp(32), dp(32), dp(80));
        TextView t = Stile.testo(this, titolo, 22, Stile.TESTO, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        if (testo != null) {
            TextView s = Stile.testo(this, testo, 15, Stile.SECONDARIO, false);
            s.setSingleLine(false);
            s.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(8);
            c.addView(s, lp);
        }
        if (pulsante != null) {
            TextView p = Stile.pulsanteTesto(this, pulsante);
            p.setOnClickListener(azione);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(8);
            c.addView(p, lp);
        }
        return c;
    }

    // ============================================================ TASTIERINO

    private View creaTastierino() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setBackgroundColor(Stile.SFONDO);

        int larg = getResources().getDisplayMetrics().widthPixels;
        int alt = getResources().getDisplayMetrics().heightPixels;
        int k = Math.min(dp(80), (larg - dp(110)) / 3);
        k = Math.min(k, (alt - dp(330)) / 5);
        k = Math.max(k, dp(56));
        int gapO = Math.min(dp(28), (larg - 3 * k) / 4);
        int gapV = Math.max(dp(10), Math.min(dp(16), k / 5));

        FrameLayout suTast = new FrameLayout(this);
        suTast.addView(ingranaggio(), new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));
        col.addView(suTast, new LinearLayout.LayoutParams(-1, dp(46)));
        col.addView(new View(this), new LinearLayout.LayoutParams(1, 0, 1f));

        display = new TextView(this);
        display.setTextColor(Stile.TESTO);
        display.setGravity(Gravity.CENTER);
        display.setMaxLines(1);
        display.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        display.setAutoSizeTextTypeUniformWithConfiguration(18, 40, 1, TypedValue.COMPLEX_UNIT_SP);
        LinearLayout.LayoutParams lpD = new LinearLayout.LayoutParams(-1, dp(56));
        lpD.leftMargin = dp(28);
        lpD.rightMargin = dp(28);
        col.addView(display, lpD);

        sottoDisplay = Stile.testo(this, "Aggiungi numero", 16, Stile.BLU, false);
        sottoDisplay.setGravity(Gravity.CENTER);
        sottoDisplay.setOnClickListener(v -> aggiungiNumeroAiContatti(digitato.toString()));
        col.addView(sottoDisplay, new LinearLayout.LayoutParams(-1, dp(28)));

        String[] cifre = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"};
        String[] lettere = {" ", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ", "", "+", ""};
        for (int r = 0; r < 4; r++) {
            LinearLayout riga = new LinearLayout(this);
            riga.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 3; c++) {
                int i = r * 3 + c;
                View t = tasto(cifre[i], lettere[i]);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(k, k);
                if (c > 0) lp.leftMargin = gapO;
                riga.addView(t, lp);
            }
            LinearLayout.LayoutParams lpR = new LinearLayout.LayoutParams(-2, -2);
            lpR.topMargin = r == 0 ? dp(14) : gapV;
            col.addView(riga, lpR);
        }

        // ultima riga: chiama + cancella
        LinearLayout basso = new LinearLayout(this);
        basso.setOrientation(LinearLayout.HORIZONTAL);
        basso.setGravity(Gravity.CENTER_VERTICAL);
        basso.addView(new View(this), new LinearLayout.LayoutParams(k, k));

        FrameLayout chiama = new FrameLayout(this);
        chiama.setBackground(Stile.premibile(Stile.tondo(Stile.VERDE), Stile.tondo(0xFF248A3D)));
        ImageView icoC = new ImageView(this);
        icoC.setImageResource(R.drawable.ic_chiama);
        icoC.setImageTintList(ColorStateList.valueOf(0xFFFFFFFF));
        chiama.addView(icoC, new FrameLayout.LayoutParams(k * 45 / 100, k * 45 / 100, Gravity.CENTER));
        chiama.setOnClickListener(v -> {
            if (digitato.length() == 0) {
                String u = Rubrica.ultimoNumero(this);
                if (!u.isEmpty()) {
                    digitato.append(u);
                    aggiornaDisplay();
                }
            } else {
                chiama(digitato.toString());
            }
        });
        LinearLayout.LayoutParams lpC = new LinearLayout.LayoutParams(k, k);
        lpC.leftMargin = gapO;
        basso.addView(chiama, lpC);

        FrameLayout canc = new FrameLayout(this);
        ImageView icoX = new ImageView(this);
        icoX.setImageResource(R.drawable.ic_cancella);
        icoX.setImageTintList(ColorStateList.valueOf(Stile.scuro ? 0xFF8E8E93 : 0xFFB4B4B9));
        canc.addView(icoX, new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        canc.setOnClickListener(v -> {
            if (digitato.length() > 0) {
                digitato.deleteCharAt(digitato.length() - 1);
                aggiornaDisplay();
            }
        });
        canc.setOnLongClickListener(v -> {
            digitato.setLength(0);
            aggiornaDisplay();
            return true;
        });
        cancella = canc;
        LinearLayout.LayoutParams lpX = new LinearLayout.LayoutParams(k, k);
        lpX.leftMargin = gapO;
        basso.addView(canc, lpX);

        LinearLayout.LayoutParams lpB = new LinearLayout.LayoutParams(-2, -2);
        lpB.topMargin = gapV;
        lpB.bottomMargin = dp(18);
        col.addView(basso, lpB);

        aggiornaDisplay();
        return col;
    }

    private View tasto(String cifra, String lettere) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Stile.premibile(Stile.tondo(Stile.TASTO), Stile.tondo(Stile.TASTO_PREMUTO)));

        float dim = cifra.equals("*") ? 42 : (cifra.equals("#") ? 32 : 34);
        TextView c = Stile.testo(this, cifra, dim, Stile.TESTO, false);
        c.setGravity(Gravity.CENTER);
        t.addView(c);
        if (!lettere.isEmpty()) {
            TextView l = Stile.testo(this, lettere, 10, Stile.TESTO, true);
            l.setLetterSpacing(0.18f);
            l.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(1);
            t.addView(l, lp);
        }
        if (cifra.equals("*")) c.setPadding(0, dp(10), 0, 0);

        final char ch = cifra.charAt(0);
        t.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                if (Rubrica.opzione(this, "vibrazione", true)) {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                }
                suona(ch);
            }
            return false;
        });
        t.setOnClickListener(v -> digita(ch));
        if (ch == '0') {
            t.setOnLongClickListener(v -> {
                digita('+');
                return true;
            });
        } else if (ch == '1') {
            t.setOnLongClickListener(v -> {
                chiamaSegreteria();
                return true;
            });
        }
        return t;
    }

    private void suona(char ch) {
        if (toni == null) return;
        if (!Rubrica.opzione(this, "toni", true)) return;
        int attivo = Settings.System.getInt(getContentResolver(), Settings.System.DTMF_TONE_WHEN_DIALING, 1);
        if (attivo == 0) return;
        int tipo;
        switch (ch) {
            case '0': tipo = ToneGenerator.TONE_DTMF_0; break;
            case '1': tipo = ToneGenerator.TONE_DTMF_1; break;
            case '2': tipo = ToneGenerator.TONE_DTMF_2; break;
            case '3': tipo = ToneGenerator.TONE_DTMF_3; break;
            case '4': tipo = ToneGenerator.TONE_DTMF_4; break;
            case '5': tipo = ToneGenerator.TONE_DTMF_5; break;
            case '6': tipo = ToneGenerator.TONE_DTMF_6; break;
            case '7': tipo = ToneGenerator.TONE_DTMF_7; break;
            case '8': tipo = ToneGenerator.TONE_DTMF_8; break;
            case '9': tipo = ToneGenerator.TONE_DTMF_9; break;
            case '*': tipo = ToneGenerator.TONE_DTMF_S; break;
            default: tipo = ToneGenerator.TONE_DTMF_P; break;
        }
        toni.startTone(tipo, 150);
    }

    private void digita(char ch) {
        if (digitato.length() >= 40) return;
        digitato.append(ch);
        aggiornaDisplay();
    }

    private void aggiornaDisplay() {
        if (display == null) return;
        String n = digitato.toString();
        display.setText(n);
        cancella.setVisibility(n.isEmpty() ? View.INVISIBLE : View.VISIBLE);
        if (n.isEmpty()) {
            sottoDisplay.setVisibility(View.INVISIBLE);
            return;
        }
        sottoDisplay.setVisibility(View.VISIBLE);
        String nome = n.length() >= 3 ? Rubrica.nomeDaNumero(this, n) : null;
        if (nome != null) {
            sottoDisplay.setText(nome);
            sottoDisplay.setTextColor(Stile.TESTO);
            sottoDisplay.setClickable(false);
        } else {
            sottoDisplay.setText("Aggiungi numero");
            sottoDisplay.setTextColor(Stile.BLU);
            sottoDisplay.setClickable(true);
        }
    }

    private void aggiungiNumeroAiContatti(String numero) {
        if (numero == null || numero.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle(numero)
                .setItems(new String[]{"Crea nuovo contatto", "Aggiungi a contatto esistente"}, (d, w) -> {
                    try {
                        Intent i;
                        if (w == 0) {
                            i = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
                        } else {
                            i = new Intent(Intent.ACTION_INSERT_OR_EDIT);
                            i.setType(ContactsContract.Contacts.CONTENT_ITEM_TYPE);
                        }
                        i.putExtra(ContactsContract.Intents.Insert.PHONE, numero);
                        startActivity(i);
                    } catch (Exception e) {
                        Toast.makeText(this, "App Contatti non trovata", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    // ============================================================ RECENTI

    private View creaRecenti() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(Stile.SFONDO);

        // controllo segmentato "Tutte | Perse"
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setBackground(Stile.rettangolo(Stile.CAMPO, dp(9)));
        seg.setPadding(dp(2), dp(2), dp(2), dp(2));
        String[] voci = {"Tutte", "Perse"};
        for (int i = 0; i < 2; i++) {
            final boolean perse = i == 1;
            TextView t = Stile.testo(this, voci[i], 13, Stile.TESTO, perse == soloPerse);
            t.setGravity(Gravity.CENTER);
            if (perse == soloPerse) {
                t.setBackground(Stile.rettangolo(Stile.scuro ? 0xFF636366 : 0xFFFFFFFF, dp(7)));
                t.setElevation(dp(1));
            }
            t.setOnClickListener(v -> {
                soloPerse = perse;
                mostraScheda(1);
            });
            seg.addView(t, new LinearLayout.LayoutParams(dp(96), dp(28)));
        }
        col.addView(intestazione(ingranaggio(), seg, null, "Recenti"));

        if (!Rubrica.permesso(this, Manifest.permission.READ_CALL_LOG)) {
            col.addView(vuoto("Recenti", "Consenti l'accesso al registro chiamate per vedere le chiamate recenti.",
                    "Consenti accesso", v -> chiediPermessi()), new LinearLayout.LayoutParams(-1, -1));
            return col;
        }

        List<Rubrica.Recente> lista = Rubrica.recenti(this, soloPerse);
        if (lista.isEmpty()) {
            col.addView(vuoto(soloPerse ? "Nessuna chiamata persa" : "Nessuna chiamata recente", null, null, null),
                    new LinearLayout.LayoutParams(-1, -1));
            return col;
        }

        ScrollView sv = new ScrollView(this);
        LinearLayout elenco = new LinearLayout(this);
        elenco.setOrientation(LinearLayout.VERTICAL);
        elenco.addView(Stile.separatore(this, 32));
        for (Rubrica.Recente r : lista) {
            elenco.addView(rigaRecente(r));
            elenco.addView(Stile.separatore(this, 32));
        }
        sv.addView(elenco);
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return col;
    }

    private View rigaRecente(Rubrica.Recente r) {
        LinearLayout riga = new LinearLayout(this);
        riga.setOrientation(LinearLayout.HORIZONTAL);
        riga.setGravity(Gravity.CENTER_VERTICAL);
        riga.setMinimumHeight(dp(60));
        riga.setPadding(0, dp(8), dp(14), dp(8));
        riga.setBackground(Stile.rigaPremibile(Stile.SFONDO));

        FrameLayout box = new FrameLayout(this);
        if (r.tipo == CallLog.Calls.OUTGOING_TYPE) {
            ImageView ic = new ImageView(this);
            ic.setImageResource(R.drawable.ic_chiama);
            ic.setImageTintList(ColorStateList.valueOf(Stile.SECONDARIO));
            box.addView(ic, new FrameLayout.LayoutParams(dp(13), dp(13), Gravity.CENTER));
        }
        riga.addView(box, new LinearLayout.LayoutParams(dp(32), dp(20)));

        LinearLayout testi = new LinearLayout(this);
        testi.setOrientation(LinearLayout.VERTICAL);
        boolean persa = Rubrica.persa(r.tipo);
        String nome = r.nome != null && !r.nome.isEmpty() ? r.nome
                : (r.numero.isEmpty() ? "Sconosciuto" : r.numero);
        if (r.conteggio > 1) nome = nome + " (" + r.conteggio + ")";
        TextView n = Stile.testo(this, nome, 17, persa ? Stile.ROSSO : Stile.TESTO, true);
        testi.addView(n);
        String sotto = r.nome != null && !r.nome.isEmpty() ? Rubrica.descrizioneTipo(r.tipo)
                : (persa ? "Chiamata persa" : Rubrica.descrizioneTipo(r.tipo));
        TextView s = Stile.testo(this, sotto, 15, Stile.SECONDARIO, false);
        LinearLayout.LayoutParams lpS = new LinearLayout.LayoutParams(-2, -2);
        lpS.topMargin = dp(3);
        testi.addView(s, lpS);
        riga.addView(testi, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView ora = Stile.testo(this, Rubrica.quando(r.data), 15, Stile.SECONDARIO, false);
        riga.addView(ora);

        ImageView info = Stile.icona(this, R.drawable.ic_info, Stile.BLU, 24);
        LinearLayout.LayoutParams lpI = (LinearLayout.LayoutParams) info.getLayoutParams();
        lpI.leftMargin = dp(10);
        info.setOnClickListener(v -> apriDettaglioNumero(r.nome, r.numero, "Recenti"));
        riga.addView(info, lpI);

        riga.setOnClickListener(v -> chiama(r.numero));
        return riga;
    }

    // ============================================================ CONTATTI

    private List<Rubrica.Contatto> tuttiContatti = new ArrayList<>();
    private final List<Object> righeContatti = new ArrayList<>();
    private AdattatoreContatti adattatore;

    private View creaContatti() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(Stile.SFONDO);

        View sinistra = null;
        if (sceltaPreferito) {
            TextView ann = Stile.pulsanteTesto(this, "Annulla");
            ann.setOnClickListener(v -> {
                sceltaPreferito = false;
                mostraScheda(0);
            });
            sinistra = ann;
        } else {
            sinistra = ingranaggio();
        }
        FrameLayout destra = iconaBarra(R.drawable.ic_aggiungi, v -> {
            try {
                startActivity(new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI));
            } catch (Exception e) {
                Toast.makeText(this, "App Contatti non trovata", Toast.LENGTH_SHORT).show();
            }
        });
        destra.setPadding(0, 0, dp(6), 0);
        col.addView(intestazione(sinistra, null, destra, sceltaPreferito ? "Scegli contatto" : "Contatti"));

        // campo di ricerca
        LinearLayout cerca = new LinearLayout(this);
        cerca.setOrientation(LinearLayout.HORIZONTAL);
        cerca.setGravity(Gravity.CENTER_VERTICAL);
        cerca.setBackground(Stile.rettangolo(Stile.CAMPO, dp(10)));
        cerca.setPadding(dp(8), 0, dp(8), 0);
        cerca.addView(Stile.icona(this, R.drawable.ic_cerca, Stile.SECONDARIO, 20));
        EditText campo = new EditText(this);
        campo.setHint("Cerca");
        campo.setHintTextColor(Stile.SECONDARIO);
        campo.setTextColor(Stile.TESTO);
        campo.setTextSize(17);
        campo.setBackground(null);
        campo.setSingleLine(true);
        campo.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        campo.setPadding(dp(6), 0, 0, 0);
        cerca.addView(campo, new LinearLayout.LayoutParams(0, -1, 1f));
        LinearLayout.LayoutParams lpC = new LinearLayout.LayoutParams(-1, dp(38));
        lpC.leftMargin = dp(16);
        lpC.rightMargin = dp(16);
        lpC.bottomMargin = dp(8);
        col.addView(cerca, lpC);

        if (!Rubrica.permesso(this, Manifest.permission.READ_CONTACTS)) {
            col.addView(vuoto("Contatti", "Consenti l'accesso ai contatti per vederli qui.",
                    "Consenti accesso", v -> chiediPermessi()), new LinearLayout.LayoutParams(-1, -1));
            return col;
        }

        tuttiContatti = Rubrica.contatti(this);
        if (tuttiContatti.isEmpty()) {
            col.addView(vuoto("Nessun contatto", null, null, null), new LinearLayout.LayoutParams(-1, -1));
            return col;
        }

        FrameLayout area = new FrameLayout(this);
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setSelector(new ColorDrawable(0));
        lv.setVerticalScrollBarEnabled(false);
        adattatore = new AdattatoreContatti();
        lv.setAdapter(adattatore);
        lv.setOnItemClickListener((p, v, pos, id) -> {
            Object o = righeContatti.get(pos);
            if (o instanceof Rubrica.Contatto) toccaContatto((Rubrica.Contatto) o);
        });
        area.addView(lv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout indice = new LinearLayout(this);
        indice.setOrientation(LinearLayout.VERTICAL);
        indice.setGravity(Gravity.CENTER);
        for (String l : LETTERE) {
            TextView t = Stile.testo(this, l, 11, Stile.BLU, true);
            t.setGravity(Gravity.CENTER);
            indice.addView(t, new LinearLayout.LayoutParams(-1, 0, 1f));
        }
        final int[] ultimo = {-1};
        indice.setOnTouchListener((v, e) -> {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            int n = LETTERE.length;
            int i = (int) (e.getY() / Math.max(1, v.getHeight()) * n);
            i = Math.max(0, Math.min(n - 1, i));
            if (i != ultimo[0]) {
                ultimo[0] = i;
                v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                int pos = posizioneLettera(LETTERE[i]);
                if (pos >= 0) {
                    lv.smoothScrollBy(0, 0); // ferma lo scorrimento in corso
                    lv.setSelectionFromTop(pos, 0);
                }
            }
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) ultimo[0] = -1;
            return true;
        });
        FrameLayout.LayoutParams lpI = new FrameLayout.LayoutParams(dp(26), -1, Gravity.END);
        lpI.topMargin = dp(12);
        lpI.bottomMargin = dp(12);
        area.addView(indice, lpI);
        if (!Rubrica.opzione(this, "indice", true)) indice.setVisibility(View.GONE);
        col.addView(area, new LinearLayout.LayoutParams(-1, 0, 1f));

        campo.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                filtra(s.toString());
                indice.setVisibility(s.length() == 0 && Rubrica.opzione(MainActivity.this, "indice", true)
                        ? View.VISIBLE : View.GONE);
            }
        });
        filtra("");
        return col;
    }

    private static String semplifica(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.ITALIAN);
    }

    private void filtra(String q) {
        righeContatti.clear();
        String f = semplifica(q.trim());
        String cifre = q.replaceAll("[^0-9+]", "");
        List<Rubrica.Contatto> lettere = new ArrayList<>();
        List<Rubrica.Contatto> altri = new ArrayList<>();
        for (Rubrica.Contatto k : tuttiContatti) {
            boolean ok = f.isEmpty() || semplifica(k.nome).contains(f);
            if (!ok && cifre.length() >= 2) {
                for (String[] n : k.numeri) {
                    if (n[1].replaceAll("[^0-9+]", "").contains(cifre)) { ok = true; break; }
                }
            }
            if (!ok) continue;
            if (Rubrica.lettera(k.nome).equals("#")) altri.add(k);
            else lettere.add(k);
        }
        String corrente = "";
        for (Rubrica.Contatto k : lettere) {
            String l = Rubrica.lettera(k.nome);
            if (!l.equals(corrente)) {
                corrente = l;
                righeContatti.add(l);
            }
            righeContatti.add(k);
        }
        if (!altri.isEmpty()) {
            righeContatti.add("#");
            righeContatti.addAll(altri);
        }
        if (adattatore != null) adattatore.notifyDataSetChanged();
    }

    private int posizioneLettera(String l) {
        int bersaglio = indiceLettera(l);
        for (int i = 0; i < righeContatti.size(); i++) {
            Object o = righeContatti.get(i);
            if (o instanceof String && indiceLettera((String) o) >= bersaglio) return i;
        }
        return righeContatti.isEmpty() ? -1 : righeContatti.size() - 1;
    }

    private static int indiceLettera(String l) {
        for (int i = 0; i < LETTERE.length; i++) if (LETTERE[i].equals(l)) return i;
        return LETTERE.length;
    }

    private void toccaContatto(Rubrica.Contatto k) {
        if (!sceltaPreferito) {
            apriDettaglio(k.nome, k.id, k.numeri, "Contatti", false);
            return;
        }
        if (k.numeri.size() == 1) {
            aggiungiPreferitoEFine(k.nome, k.numeri.get(0));
            return;
        }
        String[] voci = new String[k.numeri.size()];
        for (int i = 0; i < voci.length; i++) voci[i] = k.numeri.get(i)[0] + "  " + k.numeri.get(i)[1];
        new AlertDialog.Builder(this)
                .setTitle(k.nome)
                .setItems(voci, (d, w) -> aggiungiPreferitoEFine(k.nome, k.numeri.get(w)))
                .setNegativeButton("Annulla", null)
                .show();
    }

    private void aggiungiPreferitoEFine(String nome, String[] numero) {
        Rubrica.aggiungiPreferito(this, nome, numero[1], numero[0]);
        sceltaPreferito = false;
        mostraScheda(0);
    }

    private final class AdattatoreContatti extends BaseAdapter {
        @Override public int getCount() { return righeContatti.size(); }
        @Override public Object getItem(int p) { return righeContatti.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int p) { return righeContatti.get(p) instanceof String ? 0 : 1; }
        @Override public boolean isEnabled(int p) { return getItemViewType(p) == 1; }

        @Override
        public View getView(int p, View riuso, ViewGroup padre) {
            Object o = righeContatti.get(p);
            if (o instanceof String) {
                TextView t = riuso instanceof TextView ? (TextView) riuso : null;
                if (t == null) {
                    t = Stile.testo(MainActivity.this, "", 15, Stile.SECONDARIO, true);
                    t.setPadding(dp(16), dp(6), dp(16), dp(4));
                    t.setBackgroundColor(Stile.scuro ? 0xFF1C1C1E : 0xFFF7F7F7);
                }
                t.setText((String) o);
                return t;
            }
            LinearLayout riga = riuso instanceof LinearLayout ? (LinearLayout) riuso : null;
            if (riga == null) {
                riga = new LinearLayout(MainActivity.this);
                riga.setOrientation(LinearLayout.VERTICAL);
                riga.setBackground(Stile.rigaPremibile(Stile.SFONDO));
                TextView n = Stile.testo(MainActivity.this, "", 17, Stile.TESTO, false);
                n.setGravity(Gravity.CENTER_VERTICAL);
                n.setPadding(dp(16), 0, dp(28), 0);
                riga.addView(n, new LinearLayout.LayoutParams(-1, dp(44)));
                riga.addView(Stile.separatore(MainActivity.this, 16));
            }
            TextView n = (TextView) riga.getChildAt(0);
            String nm = ((Rubrica.Contatto) o).nome;
            n.setText(Rubrica.opzione(MainActivity.this, "grassetto", true) ? nomeConCognomeGrassetto(nm) : nm);
            return riga;
        }
    }

    /** Come l'iPhone: il cognome (ultima parola) in grassetto. */
    private static CharSequence nomeConCognomeGrassetto(String nome) {
        SpannableString ss = new SpannableString(nome);
        int sp = nome.trim().lastIndexOf(' ');
        int inizio = sp > 0 ? sp + 1 : 0;
        if (inizio < nome.length()) {
            ss.setSpan(new StyleSpan(Typeface.BOLD), inizio, nome.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return ss;
    }

    // ============================================================ SCHEDA DETTAGLIO

    private void apriDettaglioNumero(String nome, String numero, String indietro) {
        long id = Rubrica.idDaNumero(this, numero);
        Rubrica.Contatto k = id > 0 ? Rubrica.contattoDaId(this, id) : null;
        if (k != null) {
            apriDettaglio(k.nome, k.id, k.numeri, indietro, true, numero);
        } else {
            List<String[]> l = new ArrayList<>();
            l.add(new String[]{"telefono", numero});
            apriDettaglio(nome != null && !nome.isEmpty() ? nome : numero, -1, l, indietro, true, numero);
        }
    }

    private void apriDettaglio(String nome, long id, List<String[]> numeri, String indietro, boolean storico) {
        apriDettaglio(nome, id, numeri, indietro, storico, numeri.isEmpty() ? "" : numeri.get(0)[1]);
    }

    private void apriDettaglio(String nome, long id, List<String[]> numeri, String indietro,
                               boolean storico, String numeroStorico) {
        chiudiDettaglio();
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Stile.SFONDO_GRUPPO);
        sv.setClickable(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, 0, 0, dp(30));
        sv.addView(col);

        // barra superiore
        LinearLayout back = new LinearLayout(this);
        back.setOrientation(LinearLayout.HORIZONTAL);
        back.setGravity(Gravity.CENTER_VERTICAL);
        back.setPadding(dp(4), dp(8), dp(12), dp(8));
        back.addView(Stile.icona(this, R.drawable.ic_indietro, Stile.BLU, 30));
        back.addView(Stile.testo(this, indietro, 17, Stile.BLU, false));
        back.setOnClickListener(v -> chiudiDettaglio());
        View modifica = null;
        if (id > 0) {
            TextView m = Stile.pulsanteTesto(this, "Modifica");
            m.setOnClickListener(v -> {
                try {
                    Intent i = new Intent(Intent.ACTION_EDIT,
                            ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id));
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(this, "App Contatti non trovata", Toast.LENGTH_SHORT).show();
                }
            });
            modifica = m;
        }
        col.addView(intestazione(back, null, modifica, null), new LinearLayout.LayoutParams(-1, -2));

        View av = Stile.avatar(this, nome, 100);
        LinearLayout.LayoutParams lpA = (LinearLayout.LayoutParams) av.getLayoutParams();
        lpA.topMargin = dp(4);
        col.addView(av, lpA);
        TextView tn = Stile.testo(this, nome, 28, Stile.TESTO, false);
        tn.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lpN = new LinearLayout.LayoutParams(-1, -2);
        lpN.topMargin = dp(12);
        lpN.leftMargin = dp(16);
        lpN.rightMargin = dp(16);
        col.addView(tn, lpN);

        final String primo = numeri.isEmpty() ? "" : numeri.get(0)[1];

        // pulsanti azione
        LinearLayout azioni = new LinearLayout(this);
        azioni.setOrientation(LinearLayout.HORIZONTAL);
        boolean pref = Rubrica.preferito(this, primo);
        azioni.addView(pulsanteAzione(R.drawable.ic_messaggio, "messaggio", v -> messaggio(primo)));
        azioni.addView(pulsanteAzione(R.drawable.ic_chiama, "chiama", v -> scegliEChiama(nome, numeri)));
        azioni.addView(pulsanteAzione(R.drawable.ic_stella, pref ? "preferito" : "preferiti", v -> {
            if (Rubrica.preferito(this, primo)) Rubrica.rimuoviPreferito(this, primo);
            else if (!numeri.isEmpty()) Rubrica.aggiungiPreferito(this, nome, primo, numeri.get(0)[0]);
            apriDettaglio(nome, id, numeri, indietro, storico, numeroStorico);
        }));
        LinearLayout.LayoutParams lpAz = new LinearLayout.LayoutParams(-1, -2);
        lpAz.topMargin = dp(18);
        lpAz.leftMargin = dp(12);
        lpAz.rightMargin = dp(12);
        col.addView(azioni, lpAz);

        // storico chiamate (dai Recenti)
        if (storico && !numeroStorico.isEmpty()) {
            List<Rubrica.Recente> st = Rubrica.chiamateDi(this, numeroStorico);
            if (!st.isEmpty()) {
                LinearLayout c = riquadro();
                for (int i = 0; i < st.size() && i < 6; i++) {
                    Rubrica.Recente r = st.get(i);
                    if (i > 0) c.addView(Stile.separatore(this, 16));
                    LinearLayout rr = new LinearLayout(this);
                    rr.setOrientation(LinearLayout.HORIZONTAL);
                    rr.setPadding(dp(16), dp(11), dp(16), dp(11));
                    TextView d = Stile.testo(this, Rubrica.dataCompleta(r.data), 15, Stile.TESTO, false);
                    rr.addView(d, new LinearLayout.LayoutParams(0, -2, 1f));
                    String dur = Rubrica.persa(r.tipo) ? Rubrica.descrizioneTipo(r.tipo)
                            : Rubrica.descrizioneTipo(r.tipo) + (r.conteggio > 0 ? " · " + durata(r.conteggio) : "");
                    rr.addView(Stile.testo(this, dur, 15,
                            Rubrica.persa(r.tipo) ? Stile.ROSSO : Stile.SECONDARIO, false));
                    c.addView(rr);
                }
                col.addView(c, lpScheda());
            }
        }

        // numeri
        LinearLayout cn = riquadro();
        for (int i = 0; i < numeri.size(); i++) {
            String[] n = numeri.get(i);
            if (i > 0) cn.addView(Stile.separatore(this, 16));
            LinearLayout rr = new LinearLayout(this);
            rr.setOrientation(LinearLayout.VERTICAL);
            rr.setPadding(dp(16), dp(10), dp(16), dp(10));
            rr.setBackground(Stile.rigaPremibile(0x00000000));
            rr.addView(Stile.testo(this, n[0], 14, Stile.TESTO, false));
            TextView num = Stile.testo(this, n[1], 17, Stile.BLU, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(4);
            rr.addView(num, lp);
            rr.setOnClickListener(v -> chiama(n[1]));
            rr.setOnLongClickListener(v -> {
                android.content.ClipboardManager cm = getSystemService(android.content.ClipboardManager.class);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("numero", n[1]));
                Toast.makeText(this, "Numero copiato", Toast.LENGTH_SHORT).show();
                return true;
            });
            cn.addView(rr);
        }
        col.addView(cn, lpScheda());

        // azioni testuali
        LinearLayout ca = riquadro();
        ca.addView(voceTesto("Invia messaggio", Stile.BLU, v -> messaggio(primo)));
        ca.addView(Stile.separatore(this, 16));
        ca.addView(voceTesto(pref ? "Rimuovi dai preferiti" : "Aggiungi ai preferiti", Stile.BLU, v -> {
            if (Rubrica.preferito(this, primo)) Rubrica.rimuoviPreferito(this, primo);
            else if (!numeri.isEmpty()) Rubrica.aggiungiPreferito(this, nome, primo, numeri.get(0)[0]);
            apriDettaglio(nome, id, numeri, indietro, storico, numeroStorico);
        }));
        if (id <= 0) {
            ca.addView(Stile.separatore(this, 16));
            ca.addView(voceTesto("Crea nuovo contatto", Stile.BLU, v -> aggiungiNumeroAiContatti(primo)));
        }
        col.addView(ca, lpScheda());

        LinearLayout cb = riquadro();
        cb.addView(voceTesto("Blocca questo chiamante", Stile.ROSSO, v -> blocca(primo)));
        col.addView(cb, lpScheda());

        dettaglio = sv;
        contenuto.addView(sv, new FrameLayout.LayoutParams(-1, -1));
    }

    private void chiudiDettaglio() {
        if (dettaglio != null) {
            boolean impostazioni = "impostazioni".equals(dettaglio.getTag());
            contenuto.removeView(dettaglio);
            dettaglio = null;
            if (impostazioni) mostraScheda(scheda); // applica le opzioni cambiate
        }
    }

    private static String durata(int sec) {
        if (sec < 60) return sec + " s";
        if (sec < 3600) return (sec / 60) + " min";
        return (sec / 3600) + " h " + ((sec / 60) % 60) + " min";
    }

    private LinearLayout riquadro() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Stile.rettangolo(Stile.SCHEDA, dp(10)));
        c.setClipToOutline(true);
        return c;
    }

    private LinearLayout.LayoutParams lpScheda() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(18);
        lp.leftMargin = dp(16);
        lp.rightMargin = dp(16);
        return lp;
    }

    private View voceTesto(String testo, int colore, View.OnClickListener azione) {
        TextView t = Stile.testo(this, testo, 17, colore, false);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(16), 0, dp(16), 0);
        t.setMinHeight(dp(46));
        t.setBackground(Stile.rigaPremibile(0x00000000));
        t.setOnClickListener(azione);
        return t;
    }

    private View pulsanteAzione(int icona, String etichetta, View.OnClickListener azione) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        int prem = Stile.scuro ? 0xFF2C2C2E : 0xFFE5E5EA;
        b.setBackground(Stile.premibile(Stile.rettangolo(Stile.SCHEDA, dp(10)), Stile.rettangolo(prem, dp(10))));
        b.addView(Stile.icona(this, icona, Stile.BLU, 22));
        TextView t = Stile.testo(this, etichetta, 11, Stile.BLU, false);
        LinearLayout.LayoutParams lpT = new LinearLayout.LayoutParams(-2, -2);
        lpT.topMargin = dp(5);
        b.addView(t, lpT);
        b.setOnClickListener(azione);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(62), 1f);
        lp.leftMargin = dp(4);
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }

    private void scegliEChiama(String nome, List<String[]> numeri) {
        if (numeri.isEmpty()) return;
        if (numeri.size() == 1) {
            chiama(numeri.get(0)[1]);
            return;
        }
        String[] voci = new String[numeri.size()];
        for (int i = 0; i < voci.length; i++) voci[i] = numeri.get(i)[0] + "  " + numeri.get(i)[1];
        new AlertDialog.Builder(this).setTitle(nome)
                .setItems(voci, (d, w) -> chiama(numeri.get(w)[1]))
                .setNegativeButton("Annulla", null).show();
    }

    private void messaggio(String numero) {
        if (numero == null || numero.isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", numero, null)));
        } catch (Exception e) {
            Toast.makeText(this, "App Messaggi non trovata", Toast.LENGTH_SHORT).show();
        }
    }

    private void blocca(String numero) {
        if (numero == null || numero.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setMessage("Non riceverai chiamate né messaggi da " + numero + ".")
                .setPositiveButton("Blocca contatto", (d, w) -> {
                    try {
                        if (BlockedNumberContract.canCurrentUserBlockNumbers(this)) {
                            ContentValues v = new ContentValues();
                            v.put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, numero);
                            getContentResolver().insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v);
                            Toast.makeText(this, "Numero bloccato", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    } catch (Exception ignorata) { }
                    Toast.makeText(this, "Per bloccare i numeri imposta Chiamate come app Telefono predefinita",
                            Toast.LENGTH_LONG).show();
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    // ============================================================ PREFERITI

    private View creaPreferiti() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(Stile.SFONDO);

        LinearLayout sx = new LinearLayout(this);
        sx.setOrientation(LinearLayout.HORIZONTAL);
        sx.setGravity(Gravity.CENTER_VERTICAL);
        sx.setPadding(dp(6), 0, 0, 0);
        sx.addView(iconaBarra(R.drawable.ic_aggiungi, v -> {
            sceltaPreferito = true;
            modificaPreferiti = false;
            mostraScheda(2);
        }));
        sx.addView(iconaBarra(R.drawable.ic_impostazioni, v -> apriImpostazioni()));
        List<String[]> lista = Rubrica.preferiti(this);
        TextView mod = Stile.pulsanteTesto(this, modificaPreferiti ? "Fine" : "Modifica");
        if (modificaPreferiti) mod.setTypeface(Typeface.DEFAULT_BOLD);
        mod.setOnClickListener(v -> {
            modificaPreferiti = !modificaPreferiti;
            mostraScheda(0);
        });
        col.addView(intestazione(sx, null, lista.isEmpty() ? null : mod, "Preferiti"));

        if (lista.isEmpty()) {
            col.addView(vuoto("Nessun preferito", "Tocca + per aggiungere i contatti che chiami più spesso.",
                    null, null), new LinearLayout.LayoutParams(-1, -1));
            return col;
        }

        ScrollView sv = new ScrollView(this);
        LinearLayout elenco = new LinearLayout(this);
        elenco.setOrientation(LinearLayout.VERTICAL);
        elenco.addView(Stile.separatore(this, 72));
        for (String[] p : lista) {
            LinearLayout riga = new LinearLayout(this);
            riga.setOrientation(LinearLayout.HORIZONTAL);
            riga.setGravity(Gravity.CENTER_VERTICAL);
            riga.setPadding(dp(16), dp(8), dp(14), dp(8));
            riga.setBackground(Stile.rigaPremibile(Stile.SFONDO));
            if (modificaPreferiti) {
                ImageView meno = Stile.icona(this, R.drawable.ic_meno, Stile.ROSSO, 24);
                LinearLayout.LayoutParams lpM = (LinearLayout.LayoutParams) meno.getLayoutParams();
                lpM.rightMargin = dp(12);
                meno.setOnClickListener(v -> {
                    Rubrica.rimuoviPreferito(this, p[1]);
                    mostraScheda(0);
                });
                riga.addView(meno, lpM);
            }
            View av = Stile.avatar(this, p[0], 42);
            riga.addView(av);
            LinearLayout testi = new LinearLayout(this);
            testi.setOrientation(LinearLayout.VERTICAL);
            testi.setPadding(dp(14), 0, dp(8), 0);
            testi.addView(Stile.testo(this, p[0], 17, Stile.TESTO, true));
            LinearLayout sotto = new LinearLayout(this);
            sotto.setOrientation(LinearLayout.HORIZONTAL);
            sotto.setGravity(Gravity.CENTER_VERTICAL);
            sotto.addView(Stile.icona(this, R.drawable.ic_chiama, Stile.SECONDARIO, 13));
            TextView et = Stile.testo(this, " " + p[2], 14, Stile.SECONDARIO, false);
            sotto.addView(et);
            LinearLayout.LayoutParams lpS = new LinearLayout.LayoutParams(-2, -2);
            lpS.topMargin = dp(3);
            testi.addView(sotto, lpS);
            riga.addView(testi, new LinearLayout.LayoutParams(0, -2, 1f));
            if (!modificaPreferiti) {
                ImageView info = Stile.icona(this, R.drawable.ic_info, Stile.BLU, 24);
                info.setOnClickListener(v -> apriDettaglioNumero(p[0], p[1], "Preferiti"));
                riga.addView(info);
                riga.setOnClickListener(v -> chiama(p[1]));
            }
            elenco.addView(riga);
            elenco.addView(Stile.separatore(this, 72));
        }
        sv.addView(elenco);
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return col;
    }

    // ============================================================ IMPOSTAZIONI

    private String versione() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    /** Pulsante-icona della barra in alto: stessa misura per tutti, così restano allineati. */
    private FrameLayout iconaBarra(int res, View.OnClickListener azione) {
        FrameLayout f = new FrameLayout(this);
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setImageTintList(ColorStateList.valueOf(Stile.BLU));
        f.addView(iv, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(46)));
        f.setOnClickListener(azione);
        return f;
    }

    private View ingranaggio() {
        FrameLayout f = iconaBarra(R.drawable.ic_impostazioni, v -> apriImpostazioni());
        f.setPadding(dp(6), 0, 0, 0);
        return f;
    }

    private TextView titoletto(String t) {
        TextView tv = Stile.testo(this, t.toUpperCase(Locale.ITALIAN), 13, Stile.SECONDARIO, false);
        tv.setPadding(dp(32), dp(24), dp(16), dp(6));
        return tv;
    }

    private TextView notina(String t) {
        TextView tv = Stile.testo(this, t, 13, Stile.SECONDARIO, false);
        tv.setSingleLine(false);
        tv.setPadding(dp(32), dp(6), dp(32), 0);
        return tv;
    }

    private LinearLayout.LayoutParams lpGruppo() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.leftMargin = dp(16);
        lp.rightMargin = dp(16);
        return lp;
    }

    /** Riga con testo a sinistra e una vista (spunta, interruttore, valore) a destra. */
    private LinearLayout rigaImpostazione(String testo, View destra, View.OnClickListener azione) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(46));
        r.setPadding(dp(16), 0, dp(14), 0);
        if (azione != null) {
            r.setBackground(Stile.rigaPremibile(0x00000000));
            r.setOnClickListener(azione);
        }
        r.addView(Stile.testo(this, testo, 17, Stile.TESTO, false), new LinearLayout.LayoutParams(0, -2, 1f));
        if (destra != null) r.addView(destra);
        return r;
    }

    private View interruttore(String chiave, boolean predefinito) {
        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(Rubrica.opzione(this, chiave, predefinito));
        int[][] stati = {{android.R.attr.state_checked}, {}};
        sw.setTrackTintList(new ColorStateList(stati, new int[]{Stile.VERDE, Stile.scuro ? 0xFF39393D : 0xFFE9E9EA}));
        sw.setThumbTintList(new ColorStateList(stati, new int[]{0xFFFFFFFF, 0xFFFFFFFF}));
        sw.setOnCheckedChangeListener((b, si) -> Rubrica.salvaOpzione(this, chiave, si));
        return sw;
    }

    private View freccia(String valore) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        if (valore != null) l.addView(Stile.testo(this, valore, 17, Stile.SECONDARIO, false));
        l.addView(Stile.icona(this, R.drawable.ic_freccia, Stile.scuro ? 0xFF5A5A5E : 0xFFC4C4C7, 22));
        return l;
    }

    private void apriImpostazioni() {
        chiudiDettaglio();
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Stile.SFONDO_GRUPPO);
        sv.setClickable(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(40));
        sv.addView(col);

        LinearLayout back = new LinearLayout(this);
        back.setOrientation(LinearLayout.HORIZONTAL);
        back.setGravity(Gravity.CENTER_VERTICAL);
        back.setPadding(dp(4), dp(8), dp(12), dp(8));
        back.addView(Stile.icona(this, R.drawable.ic_indietro, Stile.BLU, 30));
        back.addView(Stile.testo(this, NOMI_SCHEDE[scheda], 17, Stile.BLU, false));
        back.setOnClickListener(v -> chiudiDettaglio());
        col.addView(intestazione(back, null, null, "Impostazioni"));

        // --- Aspetto
        col.addView(titoletto("Aspetto"));
        LinearLayout g1 = riquadro();
        String[] temi = {"Automatico", "Chiaro", "Scuro"};
        int attuale = Rubrica.tema(this);
        for (int i = 0; i < temi.length; i++) {
            final int t = i;
            ImageView spunta = Stile.icona(this, R.drawable.ic_spunta, Stile.BLU, 22);
            spunta.setVisibility(i == attuale ? View.VISIBLE : View.INVISIBLE);
            if (i > 0) g1.addView(Stile.separatore(this, 16));
            g1.addView(rigaImpostazione(temi[i], spunta, v -> {
                if (Rubrica.tema(this) == t) return;
                Rubrica.salvaTema(this, t);
                riapriImpostazioni = true;
                recreate();
            }));
        }
        col.addView(g1, lpGruppo());
        col.addView(notina("Automatico segue la modalità chiara o scura del telefono."));

        // --- Tastierino
        col.addView(titoletto("Tastierino"));
        LinearLayout g2 = riquadro();
        g2.addView(rigaImpostazione("Toni tastierino", interruttore("toni", true), null));
        g2.addView(Stile.separatore(this, 16));
        g2.addView(rigaImpostazione("Vibrazione tasti", interruttore("vibrazione", true), null));
        col.addView(g2, lpGruppo());

        // --- Contatti
        col.addView(titoletto("Contatti"));
        LinearLayout g3 = riquadro();
        g3.addView(rigaImpostazione("Cognome in grassetto", interruttore("grassetto", true), null));
        g3.addView(Stile.separatore(this, 16));
        g3.addView(rigaImpostazione("Indice alfabetico", interruttore("indice", true), null));
        col.addView(g3, lpGruppo());

        // --- Telefono
        col.addView(titoletto("Telefono"));
        LinearLayout g4 = riquadro();
        g4.addView(rigaImpostazione("App Telefono predefinita", freccia(predefinita() ? "Sì" : "No"),
                v -> {
                    if (predefinita()) {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
                        } catch (Exception e) {
                            Toast.makeText(this, "Chiamate è già l'app Telefono predefinita", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        richiediRuolo();
                    }
                }));
        g4.addView(Stile.separatore(this, 16));
        g4.addView(rigaImpostazione("Numeri bloccati", freccia(null), v -> {
            try {
                startActivity(getSystemService(TelecomManager.class).createManageBlockedNumbersIntent());
            } catch (Exception e) {
                Toast.makeText(this, "Non disponibile su questo telefono", Toast.LENGTH_SHORT).show();
            }
        }));
        g4.addView(Stile.separatore(this, 16));
        g4.addView(rigaImpostazione("Suoneria e vibrazione", freccia(null), v -> {
            try {
                startActivity(new Intent(Settings.ACTION_SOUND_SETTINGS));
            } catch (Exception ignorata) { }
        }));
        g4.addView(Stile.separatore(this, 16));
        g4.addView(rigaImpostazione("Permessi dell'app", freccia(null), v -> {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null)));
            } catch (Exception ignorata) { }
        }));
        col.addView(g4, lpGruppo());

        // --- Info
        col.addView(titoletto("Info"));
        LinearLayout g5 = riquadro();
        g5.addView(rigaImpostazione("Versione", Stile.testo(this, versione(), 17, Stile.SECONDARIO, false), null));
        col.addView(g5, lpGruppo());

        sv.setTag("impostazioni");
        dettaglio = sv;
        contenuto.addView(sv, new FrameLayout.LayoutParams(-1, -1));
    }

    // ============================================================ SEGRETERIA

    private View creaSegreteria() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(Stile.SFONDO);
        col.addView(intestazione(ingranaggio(), null, null, "Segreteria"));

        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(32), 0, dp(32), dp(40));
        ImageView ic = Stile.icona(this, R.drawable.ic_segreteria, Stile.SECONDARIO, 96);
        c.addView(ic);
        TextView t = Stile.testo(this, "Segreteria", 22, Stile.TESTO, true);
        LinearLayout.LayoutParams lpT = new LinearLayout.LayoutParams(-2, -2);
        lpT.topMargin = dp(12);
        c.addView(t, lpT);
        TextView s = Stile.testo(this, "Per ascoltare i tuoi messaggi chiama la segreteria del tuo operatore.",
                15, Stile.SECONDARIO, false);
        s.setSingleLine(false);
        s.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lpS = new LinearLayout.LayoutParams(-2, -2);
        lpS.topMargin = dp(8);
        c.addView(s, lpS);

        TextView b = Stile.testo(this, "Chiama segreteria", 17, 0xFFFFFFFF, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Stile.premibile(Stile.rettangolo(Stile.VERDE, dp(12)), Stile.rettangolo(0xFF248A3D, dp(12))));
        b.setOnClickListener(v -> chiamaSegreteria());
        LinearLayout.LayoutParams lpB = new LinearLayout.LayoutParams(dp(240), dp(50));
        lpB.topMargin = dp(24);
        c.addView(b, lpB);

        if (!predefinita()) {
            TextView p = Stile.testo(this, "Imposta Chiamate come app Telefono predefinita", 15, Stile.BLU, false);
            p.setSingleLine(false);
            p.setGravity(Gravity.CENTER);
            p.setPadding(dp(8), dp(12), dp(8), dp(12));
            p.setOnClickListener(v -> richiediRuolo());
            LinearLayout.LayoutParams lpP = new LinearLayout.LayoutParams(-2, -2);
            lpP.topMargin = dp(28);
            c.addView(p, lpP);
            TextView spieg = Stile.testo(this,
                    "Così anche la schermata durante le chiamate sarà quella in stile iPhone.",
                    13, Stile.SECONDARIO, false);
            spieg.setSingleLine(false);
            spieg.setGravity(Gravity.CENTER);
            c.addView(spieg);
        }
        col.addView(c, new LinearLayout.LayoutParams(-1, 0, 1f));
        return col;
    }

    // ============================================================ chiamare

    private void chiama(String numero) {
        if (numero == null || numero.trim().isEmpty()) return;
        Rubrica.salvaUltimoNumero(this, numero);
        chiamaUri(Uri.fromParts("tel", numero, null));
    }

    private void chiamaSegreteria() {
        chiamaUri(Uri.fromParts("voicemail", "", null));
    }

    private void chiamaUri(Uri uri) {
        if (!Rubrica.permesso(this, Manifest.permission.CALL_PHONE)) {
            uriInAttesa = uri;
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQ_CHIAMA);
            return;
        }
        avvia(uri);
    }

    private void avvia(Uri uri) {
        try {
            TelecomManager tm = getSystemService(TelecomManager.class);
            tm.placeCall(uri, new Bundle());
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_CALL, uri));
            } catch (Exception e2) {
                Toast.makeText(this, "Impossibile effettuare la chiamata", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ============================================================ permessi e app predefinita

    private boolean predefinita() {
        RoleManager rm = getSystemService(RoleManager.class);
        return rm != null && rm.isRoleHeld(RoleManager.ROLE_DIALER);
    }

    @SuppressWarnings("deprecation")
    private void richiediRuolo() {
        RoleManager rm = getSystemService(RoleManager.class);
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
            try {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), REQ_RUOLO);
                return;
            } catch (Exception ignorata) { }
        }
        chiediPermessi();
    }

    private void chiediPermessi() {
        List<String> p = new ArrayList<>();
        String[] servono = {Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG,
                Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE};
        for (String s : servono) if (!Rubrica.permesso(this, s)) p.add(s);
        if (Build.VERSION.SDK_INT >= 33 && !Rubrica.permesso(this, Manifest.permission.POST_NOTIFICATIONS)) {
            p.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), REQ_PERMESSI);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_RUOLO) {
            chiediPermessi();
            if (dettaglio == null) mostraScheda(scheda);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CHIAMA) {
            Uri u = uriInAttesa;
            uriInAttesa = null;
            if (u == null) return;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) avvia(u);
            else {
                try {
                    startActivity(new Intent(Intent.ACTION_DIAL, u));
                } catch (Exception ignorata) { }
            }
        } else if (requestCode == REQ_PERMESSI) {
            if (dettaglio == null) mostraScheda(scheda);
        }
    }
}
